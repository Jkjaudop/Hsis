[/Script/ShadowTrackerExtra.STBaseCharacter]
ClientHitPartJudgment=True+99.99999
HitPartJudgment=True+99.99999
DSHitPartJudgment=True+99.99999
UseShootVerifyEx=True+99.99999



//ᴢᴀᴠɪᴋ ᴄғɢ TDM//