[/Script/ShadowTrackerExtra.STExtraBaseCharacter]
ClientHitPartJudgment="HEAD"//"Max"
ClientAimAssistJudgment="HEAD"//"Max"
ClientAimPart="HEAD"//"Max"
ClientBulletHitPartJudgment="HEAD"//"Max"
ClientHeadshotPercentage=Max
ClientHeadshotJudgement=Max
ClientBulletDamageJudgement=Max
ClientFPSJudgement=MAX
ClientFPSJudgement=Max
UseShootVerifyEx=false
ClientAimAssistJudgment="100000%"
ClientAimPart="HEAD"
ClientBulletHitPartJudgment="HEAD"//"Max"
ClientHeadshotPercentage="100000%"
ClientHeadshotJudgement="100000%"
ClientBulletDamageJudgement="10000%"

[/Script/ShadowTrackerExtra.MagicBullet]

MagicBullet=Max//Enable
Aimbot360°=Max//Enable
Aimlock=Max//Enable
Headshot=Max//Enable
UltraHeadshot=Max//Enable
55/55/MagicBullet=Max//Enable
BulletTracking=Max//Enable
HighDamage=Max//Enable
IpadView=Max//Enable
NoGrassMax//Enable


//ᴢᴀᴠɪᴋ ᴄғɢ TDM//