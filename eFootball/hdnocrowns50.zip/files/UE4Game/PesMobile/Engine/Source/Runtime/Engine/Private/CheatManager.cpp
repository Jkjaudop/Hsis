Slomo=10
