virtual void Slomo
(
    float NewTimeDilation
)