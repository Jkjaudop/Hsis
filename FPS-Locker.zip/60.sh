sleep 1
echo ""
echo ""

(
# Applying optimized FPS properties (debug)
setprop debug.sys.display.fps 60
setprop debug.sys.display_refresh_rate 60
setprop debug.sys.display.refresh_rate 60
setprop debug.sys.game.minfps 60
setprop debug.sys.game.maxfps 60
setprop debug.sys.game.minframerate 60
setprop debug.sys.game.maxframerate 60
setprop debug.sys.min_refresh_rate 60
setprop debug.sys.max_refresh_rate 60
setprop debug.sys.peak_refresh_rate 60
setprop debug.sys.sf.fps 60
setprop debug.sys.smartfps 1
setprop debug.sys.display.min_refresh_rate 60
setprop debug.sys.vsync_optimization_enable false
setprop debug.sys.hwui.dyn_vsync 0
setprop debug.sys.vsync false
setprop debug.sys.hwui.fps_mode 1
setprop debug.sys.first.frame.accelerates true
setprop debug.sys.fps_unlock_allowed 60
setprop debug.sys.display.max_fps 60
setprop debug.sys.video.max.fps 60
setprop debug.sys.surfaceflinger.idle_reduce_framerate_enable false
) > /dev/null 2>&1 &

(
# Stable Optimized FPS (Device Sys Props)
setprop sys.display.fps 60
setprop sys.display_refresh_rate 60
setprop sys.display.refresh_rate 60
setprop sys.game.minfps 60
setprop sys.game.maxfps 60
setprop sys.game.minframerate 60
setprop sys.game.maxframerate 60
setprop sys.min_refresh_rate 60
setprop sys.max_refresh_rate 60
setprop sys.peak_refresh_rate 60
setprop sys.sf.fps 60
setprop sys.smartfps 1
setprop sys.display.min_refresh_rate 60
setprop sys.vsync_optimization_enable false
setprop sys.hwui.dyn_vsync 0
setprop sys.vsync false
setprop sys.hwui.fps_mode 1
setprop sys.first.frame.accelerates true
setprop sys.fps_unlock_allowed 60
setprop sys.display.max_fps 60
setprop sys.video.max.fps 60
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
) > /dev/null 2>&1 &

(
# Optimize Refresh Rate + Game Tweaks
settings put global refresh_rate_mode 1
settings put global refresh_rate_switching_type 1
settings put global refresh_rate_force_high 1
setprop debug.hwui.refresh_rate 60
setprop debug.sf.perf_mode 1
settings put global surface_flinger.use_content_detection_for_refresh_rate false
settings put global media.recorder-max-base-layer-fps 60
settings put global vendor.fps.switch.default true
settings put system vendor.disable_idle_fps true
settings put global vendor.display.default_fps 60
settings put system vendor.display.idle_default_fps 60
settings put system vendor.display.enable_optimize_refresh 1
settings put system vendor.display.video_or_camera_fps.support true
setprop debug.sf.set_idle_timer_ms 500
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.high_fps_early_phase_offset_ns 2000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 500000
settings put system game_driver_min_frame_rate 60
settings put system game_driver_max_frame_rate 60
settings put system game_driver_power_saving_mode 0
settings put system game_driver_frame_skip_enable 0
settings put system game_driver_vsync_enable 0
settings put system game_driver_gpu_mode 1
settings put system game_driver_fps_limit 60
) > /dev/null 2>&1 &

(
# FPS Injector Tweaks
setprop debug.graphics.game_default_frame_rate 60
setprop debug.graphics.game_default_frame_rate.disabled false
setprop persist.sys.gpu_perf_mode 1
setprop debug.mtk.powerhal.hint.bypass 1
setprop persist.sys.surfaceflinger.idle_reduce_framerate_enable false
setprop sys.surfaceflinger.idle_reduce_framerate_enable false
setprop debug.sf.perf_mode 1
settings put global refresh.active 1
setprop debug.hwui.disable_vsync true
setprop debug.performance.profile 1
setprop debug.perf.tuning 1
) > /dev/null 2>&1 &

(
# FPS Lock + Rate Control
settings put system user_refresh_rate 60
settings put system fps_limit 60
settings put system max_refresh_rate_for_ui 60
settings put system hwui_refresh_rate 60
settings put system display_refresh_rate 60
settings put system max_refresh_rate_for_gaming 60
settings put system fstb_target_fps_margin_high_fps 20
settings put system fstb_target_fps_margin_low_fps 20
settings put system gcc_fps_margin 10
settings put system tran_low_battery_60hz_refresh_rate.support 0
settings put system vendor.display.refresh_rate 60
settings put system user_refresh_rate 1
settings put system sf.refresh_rate 60
settings put secure user_refresh_rate 1
settings put secure miui_refresh_rate 60
settings put system min_frame_rate 60
settings put system max_frame_rate 60
settings put system tran_refresh_mode 60
settings put system last_tran_refresh_mode_in_refresh_setting 60
settings put global min_fps 60
settings put global max_fps 60
settings put system tran_need_recovery_refresh_mode 60
settings put system display_min_refresh_rate 60
settings put system min_refresh_rate 60
settings put system max_refresh_rate 60
settings put system peak_refresh_rate 60
settings put secure refresh_rate_mode 60
settings put system thermal_limit_refresh_rate 60
settings put system NV_FPSLIMIT 60
settings put system fps.limit.is.now locked
) > /dev/null 2>&1 &