#!/system/bin/sh

clear
echo ""
echo "⚡------------------------------------------⚡"
echo "🎮  SHIZUKO FPS BOOST UNINSTALLER 🎮"
echo "      Reverting to Default System Values"
echo "          by Minamahal ❤️ 2025 Edition"
echo "⚡------------------------------------------⚡"
sleep 1

# Revert CPU governor
settings put global cpu.governor "sched"
echo "✅ CPU governor reverted to sched"

# Revert GPU
settings put global gpu.turbo 0
settings put global gpu.governor "default"
echo "✅ GPU Turbo disabled and governor defaulted"

# Revert scheduler
settings put global sched.boost 0
echo "✅ Scheduler boost removed"

# SurfaceFlinger revert
settings put global debug.sf.latch_unsignaled 0
settings put global debug.sf.enable_gl_backpressure 1
echo "✅ SurfaceFlinger values restored"

# Revert thermal settings
settings put global thermal.config "default"
settings put global thermal.mode "normal"
echo "✅ Thermal mode back to normal"

# Touch boost revert
settings put global touch.response 0
echo "✅ Touch boost disabled"

# Dynamic FPS revert
settings delete global fps.boost.mode
settings delete global fps.boost.level
echo "✅ Dynamic FPS boost removed"

echo ""
echo "✅ Shizuko FPS Boost settings successfully reverted!"
echo "💖 Thanks to: minamahal ko & minamahal ❤️"
echo "⚡------------------------------------------⚡"