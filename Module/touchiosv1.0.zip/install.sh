echo "╔╦╗ ╔═╗ ╦┈╦ ╔═╗ ╦┈╦  
┈║┈ ║┈║ ║┈║ ║┈┈ ╠═╣  
┈╩┈ ╚═╝ ╚═╝ ╚═╝ ╩┈╩  
╦ ╔═╗ ╔═╗  
║ ║┈║ ╚═╗  
╩ ╚═╝ ╚═╝  
"
echo ""
echo "Instalasi Touch ios v2.4 Please Waite"
echo ""
set_touch() {
settings put systemui min_refresh_rate_for_fps_boost 60 
settings put systemui max_refresh_rate_for_fps_boost 60 
settings put systemui peak_refresh_rate 60.0 
settings put systemui min_refresh_rate 60.0 
settings put system min_refresh_rate_for_fps_boost 60 
settings put system max_refresh_rate_for_fps_boost 60 
settings put system peak_refresh_rate 60.0 
settings put system min_refresh_rate 60.0 
settings put systemui tran_need_recovery_refresh_mode 60 
settings put systemui last_tran_refresh_mode_in_refresh_setting 60 
settings put systemui tran_refresh_mode 60 
settings put system tran_need_recovery_refresh_mode 60 
settings put system last_tran_refresh_mode_in_refresh_setting 60 
settings put system tran_refresh_mode 60 
settings put global burn_in_protection 0 
}

set_touch > /dev/null 2>&1 

#Tweaks
set_surface() {
setprop debug.touchscreen.latency.scale 0,5 
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 60 
setprop debug.hwui.profile.maxframes 60 
setprop debug.javafx.animation.fullspeed 1 
setprop debug.javafx.animation.framerate 60 
setprop debug.redroid.fps 60 
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1 
setprop debug.sf.hwc_hdcp_via_neg_vsync 1 
setprop debug.sf.set_binder_thread_rt 1 
setprop debug.sf.showcpu 0 
setprop debug.sf.showupdates 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.sf.hw 0 
setprop debug.sf.enable_hgl 0 
setprop debug.sf.ddms 1 
setprop debug.sf.dump 0 
setprop debug.sf.set_idle_timer_ms 0 
setprop debug.sf.treat_170m_as_sRGB 0 
setprop debug.sf.max_igbp_list_size 0 
setprop debug.sf.disable_hwc_vds 1 
setprop debug.sf.enable_egl_image_tracker 0 
setprop debug.sf.luma_sampling 1 
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_advanced_sf_phase_offset 0 
setprop debug.sf.enable_gl_backpressure 0 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 0 
setprop debug.sf.gpu_freq_index 7 
setprop debug.sf.auto_latch_unsignaled 0 
setprop debug.sf.enable_hwc_vds 0 
setprop debug.sf.show_predicted_vsync 0 
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.kernel_idle_timer_update_overlay 1 
setprop debug.sf.support_kernel_idle_timer_enabled 0 
setprop debug.sf.vsync_reactor_ignore_present_fences 0 
setprop debug.sf.enable_transaction_tracing 0 
setprop debug.sf.use_phase_offsets_as_durations 0 
setprop debug.sf.ignore_hwc_physical_display_orientation 0 
setprop debug.sf.enable_adpf_cpu_hint 1 
setprop debug.sf.frame_rate_multiple_threshold 60 
setprop debug.sf_frame_rate_multiple_fences 60 
setprop debug.sf.early.app.duration 20000000 
setprop debug.sf.early.sf.duration 27600000 
setprop debug.sf.hwc.min.duration 23000000 
setprop debug.sf.late.app.duration 20000000 
setprop debug.sf.late.sf.duration 27600000 
setprop debug.sf.earlyGl.sf.duration 27600000 
setprop debug.sf.60_fps.early.app.duration 8333333 
setprop debug.sf.60_fps.early.sf.duration 11500000 
setprop debug.sf.60_fps.earlyGl.app.duration 8333333 
setprop debug.sf.60_fps.earlyGl.sf.duration 11500000 
setprop debug.sf.60_fps.late.app.duration 8333333 
setprop debug.sf.60_fps.late.sf.duration 11500000 
setprop debug.sf.high_fps.early.app.duration 10000000 
setprop debug.sf.high_fps.early.sf.duration 13800000 
setprop debug.sf.high_fps.earlyGl.app.duration 10000000 
setprop debug.sf.high_fps.earlyGl.sf.duration 13800000 
setprop debug.sf.high_fps.late.app.duration 10000000 
setprop debug.sf.high_fps.late.sf.duration 13800000 
setprop debug.sf.high_fps.hwc.min.duration 8500000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.earlyGl.app.duration 20000000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.early_phase_offset_ns 500000 
}
set_surface > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Surface Flinger
set_surface() {
properties=(
  "debug.sf.disable_backpressure 1"
  "debug.sf.hwc_hotplug_error_via_neg_vsync 1"
  "debug.sf.hwc_hdcp_via_neg_vsync 1"
  "debug.sf.set_binder_thread_rt 1"
  "debug.sf.gpu_freq_index 7"
  "debug.sf.ignore_hwc_physical_display_orientation 0"
  "debug.sf.enable_adpf_cpu_hint 1"
  "debug.sf.latch_unsignaled 0"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.disable_hwc_vds 1"
  "debug.sf.frame_rate_multiple_threshold 60"
  "debug.sf_frame_rate_multiple_fences 60"
  "debug.sf.enable_egl_image_tracker 0"
  "debug.sf.luma_sampling 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.auto_latch_unsignaled 0"
  "debug.sf.early.app.duration 20000000"
  "debug.sf.early.sf.duration 27600000"
  "debug.sf.earlyGl.app.duration 20000000"
  "debug.sf.earlyGl.sf.duration 27600000"
  "debug.sf.late.app.duration 20000000"
  "debug.sf.late.sf.duration 27600000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.hwc.min.duration 23000000"
  "debug.sf.enable_gl_backpressure 0"
  "debug.sf.enable_transaction_tracing false"
  "debug.sf.enable_hgl 0"
  "debug.sf.ddms 1"
  "debug.sf.dump 0"
  "debug.sf.max_igbp_list_size 0"
  "debug.sf.showupdates 0"
  "debug.sf.showcpu 0"
  "debug.sf.showbackground 0"
  "debug.sf.showfps 0"
  "debug.sf.hw 0"
  "debug.sf.disable_client_composition_cache 1"
  "debug.sf.enable_advanced_sf_phase_offset 0"
  "debug.sf.use_phase_offsets_as_durations 0"
  "debug.sf.predict_hwc_composition_strategy 0"
  "debug.sf.treat_170m_as_sRGB 0"
  "debug.sf.set_idle_timer_ms 0"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
  "debug.sf.60_fps.early.app.duration 8333333"
  "debug.sf.60_fps.early.sf.duration 11500000"
  "debug.sf.60_fps.earlyGl.app.duration 8333333"
  "debug.sf.60_fps.earlyGl.sf.duration 11500000"
  "debug.sf.60_fps.late.app.duration 8333333"
  "debug.sf.60_fps.late.sf.duration 11500000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.high_fps.late.app.duration 10000000"
  "debug.sf.high_fps.early.sf.duration 13800000"
  "debug.sf.high_fps.early.app.duration 10000000"
  "debug.sf.high_fps.earlyGl.sf.duration 13800000"
  "debug.sf.high_fps.earlyGl.app.duration 10000000"
  "debug.sf.high_fps.hwc.min.duration 8500000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done
}
set_surface > /dev/null 2>&1 

#Other
(
  settings put global window_animation_scale 0,5 
  settings put global transition_animation_scale 0,5 
  settings put global animator_duration_scale 0,5 
)> /dev/null 2>&1 

set_surface() {
settings put surfaceflinger refresh_rate 60 
settings put surfaceflinger max_frame_buffer_acquired_count 3 
settings put surfaceflinger use_content_detection_for_refresh_rate 1  
settings put surfaceflinger game_default_frame_rate_override 60 
settings put surfaceflinger enable_frame_rate_override 0  
settings put surfaceflinger has_HDR_display 0 
settings put surfaceflinger supports_background_blur 1 
settings put surfaceflinger primary_display_orientation 0  
settings put surfaceflinger force_hwc_copy_for_virtual_displays 0 
settings put surfaceflinger protected_contents 1  
settings put surfaceflinger uclamp.min 130 
settings put surfaceflinger has_wide_color_display 0 
settings put surfaceflinger use_color_management 0 
settings put surfaceflinger set_touch_timer_ms 0 
settings put surfaceflinger max_virtual_display_dimension 4096 
settings put surfaceflinger wcg_composition_dataspace 143261696 
settings put surfaceflinger clear_slots_with_set_layer_buffer 0 
settings put surfaceflinger set_idle_timer_ms 0 
settings put surfaceflinger set_display_power_timer_ms 0 
settings put surfaceflinger enable_hwc 0 
settings put surfaceflinger min_swap_interval 0 
settings put surfaceflinger disable_expensive_timestamps 1 
settings put surfaceflinger enable_vds_tweak 0 
settings put surfaceflinger vsync_eventphase_offset_ns 6300000 
settings put surfaceflinger vsync_sfoffset_ns 6300000 
settings put surfaceflinger enable_debug_sf_vs 0 
sertings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.sampling_profiler 1
settings put global persist.sys.scrollingcache 2 
settings put global persist.sys.fps_unlock_allowed 60 
settings put global sys.fps_unlock_allowed 60 
settings put global persist.sys.ui.hw 1 
settings put global persist.sys.perf.topAppRenderThreadBoost.enable 1 
settings put global persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing 0 
settings put global persist.sys.ui.hw 1 
settings put global persist.vendor.color.matrix 2 
settings put global persist.sys.minfree_6g 16384,20480,32768,131072,230400,286720 
settings put global persist.sys.minfree_8g 16384,20480,32768,131072,384000,524288 
settings put global persist.sys.minfree_12g 16384,20480,131072,384000,524288,819200 
settings put global persist.sys.minfree_def 16384,20480,32768,131072,230400,286720 
settings put global persist.vendor.qti.inputopts.enable 1 
settings put global persist.vendor.qti.inputopts.movetouchslop 1 
settings put global persist.sys.NV_FPSLIMIT 60 
settings put global persist.sys.NV_POWERMODE 1 
settings put global persist.sys.NV_PROFVER 15 
settings put global persist.sys.NV_STEREOCTRL 0 
settings put global persist.sys.NV_STEREOSEPCHG 0 
settings put global persist.sys.NV_STEREOSEP 20 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.device_config.nnapi_native.current_feature_level 7 
settings put global persist.device_config.nnapi_native.telemetry_enable 0 
settings put global persist.device_config.runtime_native.metrics.reporting-mods 2 
settings put global persist.device_config.runtime_native.metrics.reporting-mods-server 2 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods 100 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods-server 100 
settings put global persist.device_config.runtime_native.metrics.reporting-spec 1,5,30,60,600 
settings put global persist.device_config.runtime_native.metrics.reporting-spec-server 1,10,60,3600,*
settings put global persist.device_config.runtime_native.metrics.write-to-statsd 1 
settings put global persist.device_config.runtime_native.usap_pool_size_max 0 
settings put global persist.device_config.runtime_native.use_app_image_startup_cache 1 
settings put global persist.device_config.runtime_native_boot.disable_lock_profiling 0 
settings put global persist.device_config.runtime_native_boot.enable_uffd_gc_2 0 
settings put global persist.device_config.runtime_native_boot.iorap_blacklisted_packages 0 
settings put global persist.device_config.runtime_native_boot.iorap_perfetto_enable 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0 
settings put global persist.device_config.runtime_native_boot.iorapd_options 0 
settings put global persist.device_config.tethering.bpf_net_maps_enable_java_bpf_map 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0
}

set_surface > /dev/null 2>&1 

#AndroidConfig
set_android() { 
cmd device_config put surfaceflinger refresh_rate 60 
cmd device_config put surfaceflinger max_frame_buffer_acquired_count 3 
cmd device_config put surfaceflinger use_content_detection_for_refresh_rate 1 
cmd device_config put surfaceflinger game_default_frame_rate_override 60  
cmd device_config put surfaceflinger enable_frame_rate_override 0 
cmd device_config put surfaceflinger has_HDR_display 0 
cmd device_config put surfaceflinger supports_background_blur 1 
cmd device_config put surfaceflinger primary_display_orientation 0 
cmd device_config put surfaceflinger force_hwc_copy_for_virtual_displays 0 
cmd device_config put surfaceflinger protected_contents 1 
cmd device_config put surfaceflinger uclamp.min 130 
cmd device_config put surfaceflinger has_wide_color_display 0 
cmd device_config put surfaceflinger use_color_management 0 
cmd device_config put surfaceflinger set_touch_timer_ms 0 
cmd device_config put surfaceflinger max_virtual_display_dimension 4096 
cmd device_config put surfaceflinger wcg_composition_dataspace 143261696 
cmd device_config put surfaceflinger clear_slots_with_set_layer_buffer 0 
cmd device_config put surfaceflinger set_idle_timer_ms 0 
cmd device_config put surfaceflinger set_display_power_timer_ms 0 
cmd device_config put surfaceflinger enable_hwc 0 
cmd device_config put surfaceflinger min_swap_interval 0 
cmd device_config put surfaceflinger disable_expensive_timestamps 1 
cmd device_config put surfaceflinger enable_vds_tweak 0 
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 6300000 
cmd device_config put surfaceflinger vsync_sfoffset_ns 6300000 
cmd device_config put surfaceflinger enable_debug_sf_vs 0 
}
set_android > /dev/null 2>&1 
set_touch() {
settings put systemui min_refresh_rate_for_fps_boost 90 
settings put systemui max_refresh_rate_for_fps_boost 90 
settings put systemui peak_refresh_rate 90.0 
settings put systemui min_refresh_rate 90.0 
settings put system min_refresh_rate_for_fps_boost 90 
settings put system max_refresh_rate_for_fps_boost 90 
settings put system peak_refresh_rate 90.0 
settings put system min_refresh_rate 90.0 
settings put systemui tran_need_recovery_refresh_mode 90 
settings put systemui last_tran_refresh_mode_in_refresh_setting 90 
settings put systemui tran_refresh_mode 90 
settings put system tran_need_recovery_refresh_mode 90 
settings put system last_tran_refresh_mode_in_refresh_setting 90 
settings put system tran_refresh_mode 90 
settings put global burn_in_protection 0 
}

set_touch > /dev/null 2>&1 

#Tweaks
set_surface() {
setprop debug.touchscreen.latency.scale 0,5 
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 90 
setprop debug.hwui.profile.maxframes 90 
setprop debug.javafx.animation.fullspeed 1 
setprop debug.javafx.animation.framerate 90 
setprop debug.redroid.fps 90 
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1 
setprop debug.sf.hwc_hdcp_via_neg_vsync 1 
setprop debug.sf.set_binder_thread_rt 1 
setprop debug.sf.showcpu 0 
setprop debug.sf.showupdates 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.sf.hw 0 
setprop debug.sf.enable_hgl 0 
setprop debug.sf.ddms 1 
setprop debug.sf.dump 0 
setprop debug.sf.set_idle_timer_ms 0 
setprop debug.sf.treat_170m_as_sRGB 0 
setprop debug.sf.max_igbp_list_size 0 
setprop debug.sf.disable_hwc_vds 1 
setprop debug.sf.enable_egl_image_tracker 0 
setprop debug.sf.luma_sampling 1 
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_advanced_sf_phase_offset 0 
setprop debug.sf.enable_gl_backpressure 0 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 0 
setprop debug.sf.gpu_freq_index 7 
setprop debug.sf.auto_latch_unsignaled 0 
setprop debug.sf.enable_hwc_vds 0 
setprop debug.sf.show_predicted_vsync 0 
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.kernel_idle_timer_update_overlay 1 
setprop debug.sf.support_kernel_idle_timer_enabled 0 
setprop debug.sf.vsync_reactor_ignore_present_fences 0 
setprop debug.sf.enable_transaction_tracing 0 
setprop debug.sf.use_phase_offsets_as_durations 0 
setprop debug.sf.ignore_hwc_physical_display_orientation 0 
setprop debug.sf.enable_adpf_cpu_hint 1 
setprop debug.sf.frame_rate_multiple_threshold 90 
setprop debug.sf_frame_rate_multiple_fences 90 
setprop debug.sf.early.app.duration 20000000 
setprop debug.sf.early.sf.duration 27600000 
setprop debug.sf.hwc.min.duration 23000000 
setprop debug.sf.late.app.duration 20000000 
setprop debug.sf.late.sf.duration 27600000 
setprop debug.sf.earlyGl.sf.duration 27600000 
setprop debug.sf.90_fps.early.app.duration 8333333 
setprop debug.sf.90_fps.early.sf.duration 11500000 
setprop debug.sf.90_fps.earlyGl.app.duration 8333333 
setprop debug.sf.90_fps.earlyGl.sf.duration 11500000 
setprop debug.sf.90_fps.late.app.duration 8333333 
setprop debug.sf.90_fps.late.sf.duration 11500000 
setprop debug.sf.high_fps.early.app.duration 10000000 
setprop debug.sf.high_fps.early.sf.duration 13800000 
setprop debug.sf.high_fps.earlyGl.app.duration 10000000 
setprop debug.sf.high_fps.earlyGl.sf.duration 13800000 
setprop debug.sf.high_fps.late.app.duration 10000000 
setprop debug.sf.high_fps.late.sf.duration 13800000 
setprop debug.sf.high_fps.hwc.min.duration 8500000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.earlyGl.app.duration 20000000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.early_phase_offset_ns 500000 
}
set_surface > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Surface Flinger
set_surface() {
properties=(
  "debug.sf.disable_backpressure 1"
  "debug.sf.hwc_hotplug_error_via_neg_vsync 1"
  "debug.sf.hwc_hdcp_via_neg_vsync 1"
  "debug.sf.set_binder_thread_rt 1"
  "debug.sf.gpu_freq_index 7"
  "debug.sf.ignore_hwc_physical_display_orientation 0"
  "debug.sf.enable_adpf_cpu_hint 1"
  "debug.sf.latch_unsignaled 0"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.disable_hwc_vds 1"
  "debug.sf.frame_rate_multiple_threshold 90"
  "debug.sf_frame_rate_multiple_fences 90"
  "debug.sf.enable_egl_image_tracker 0"
  "debug.sf.luma_sampling 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.auto_latch_unsignaled 0"
  "debug.sf.early.app.duration 20000000"
  "debug.sf.early.sf.duration 27600000"
  "debug.sf.earlyGl.app.duration 20000000"
  "debug.sf.earlyGl.sf.duration 27600000"
  "debug.sf.late.app.duration 20000000"
  "debug.sf.late.sf.duration 27600000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.hwc.min.duration 23000000"
  "debug.sf.enable_gl_backpressure 0"
  "debug.sf.enable_transaction_tracing false"
  "debug.sf.enable_hgl 0"
  "debug.sf.ddms 1"
  "debug.sf.dump 0"
  "debug.sf.max_igbp_list_size 0"
  "debug.sf.showupdates 0"
  "debug.sf.showcpu 0"
  "debug.sf.showbackground 0"
  "debug.sf.showfps 0"
  "debug.sf.hw 0"
  "debug.sf.disable_client_composition_cache 1"
  "debug.sf.enable_advanced_sf_phase_offset 0"
  "debug.sf.use_phase_offsets_as_durations 0"
  "debug.sf.predict_hwc_composition_strategy 0"
  "debug.sf.treat_170m_as_sRGB 0"
  "debug.sf.set_idle_timer_ms 0"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
  "debug.sf.90_fps.early.app.duration 8333333"
  "debug.sf.90_fps.early.sf.duration 11500000"
  "debug.sf.90_fps.earlyGl.app.duration 8333333"
  "debug.sf.90_fps.earlyGl.sf.duration 11500000"
  "debug.sf.90_fps.late.app.duration 8333333"
  "debug.sf.90_fps.late.sf.duration 11500000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.high_fps.late.app.duration 10000000"
  "debug.sf.high_fps.early.sf.duration 13800000"
  "debug.sf.high_fps.early.app.duration 10000000"
  "debug.sf.high_fps.earlyGl.sf.duration 13800000"
  "debug.sf.high_fps.earlyGl.app.duration 10000000"
  "debug.sf.high_fps.hwc.min.duration 8500000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done
}
set_surface > /dev/null 2>&1 

#Other
(
  settings put global window_animation_scale 0,5 
  settings put global transition_animation_scale 0,5 
  settings put global animator_duration_scale 0,5 
)> /dev/null 2>&1 

set_surface() {
settings put surfaceflinger refresh_rate 90 
settings put surfaceflinger max_frame_buffer_acquired_count 3 
settings put surfaceflinger use_content_detection_for_refresh_rate 1  
settings put surfaceflinger game_default_frame_rate_override 90 
settings put surfaceflinger enable_frame_rate_override 0  
settings put surfaceflinger has_HDR_display 0 
settings put surfaceflinger supports_background_blur 1 
settings put surfaceflinger primary_display_orientation 0  
settings put surfaceflinger force_hwc_copy_for_virtual_displays 0 
settings put surfaceflinger protected_contents 1  
settings put surfaceflinger uclamp.min 130 
settings put surfaceflinger has_wide_color_display 0 
settings put surfaceflinger use_color_management 0 
settings put surfaceflinger set_touch_timer_ms 0 
settings put surfaceflinger max_virtual_display_dimension 4096 
settings put surfaceflinger wcg_composition_dataspace 143261696 
settings put surfaceflinger clear_slots_with_set_layer_buffer 0 
settings put surfaceflinger set_idle_timer_ms 0 
settings put surfaceflinger set_display_power_timer_ms 0 
settings put surfaceflinger enable_hwc 0 
settings put surfaceflinger min_swap_interval 0 
settings put surfaceflinger disable_expensive_timestamps 1 
settings put surfaceflinger enable_vds_tweak 0 
settings put surfaceflinger vsync_eventphase_offset_ns 6300000 
settings put surfaceflinger vsync_sfoffset_ns 6300000 
settings put surfaceflinger enable_debug_sf_vs 0 
sertings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.sampling_profiler 1
settings put global persist.sys.scrollingcache 2 
settings put global persist.sys.fps_unlock_allowed 90 
settings put global sys.fps_unlock_allowed 90 
settings put global persist.sys.ui.hw 1 
settings put global persist.sys.perf.topAppRenderThreadBoost.enable 1 
settings put global persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing 0 
settings put global persist.sys.ui.hw 1 
settings put global persist.vendor.color.matrix 2 
settings put global persist.sys.minfree_6g 16384,20480,32768,131072,230400,286720 
settings put global persist.sys.minfree_8g 16384,20480,32768,131072,384000,524288 
settings put global persist.sys.minfree_12g 16384,20480,131072,384000,524288,819200 
settings put global persist.sys.minfree_def 16384,20480,32768,131072,230400,286720 
settings put global persist.vendor.qti.inputopts.enable 1 
settings put global persist.vendor.qti.inputopts.movetouchslop 1 
settings put global persist.sys.NV_FPSLIMIT 90 
settings put global persist.sys.NV_POWERMODE 1 
settings put global persist.sys.NV_PROFVER 15 
settings put global persist.sys.NV_STEREOCTRL 0 
settings put global persist.sys.NV_STEREOSEPCHG 0 
settings put global persist.sys.NV_STEREOSEP 20 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.device_config.nnapi_native.current_feature_level 7 
settings put global persist.device_config.nnapi_native.telemetry_enable 0 
settings put global persist.device_config.runtime_native.metrics.reporting-mods 2 
settings put global persist.device_config.runtime_native.metrics.reporting-mods-server 2 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods 100 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods-server 100 
settings put global persist.device_config.runtime_native.metrics.reporting-spec 1,5,30,60,600 
settings put global persist.device_config.runtime_native.metrics.reporting-spec-server 1,10,60,3600,*
settings put global persist.device_config.runtime_native.metrics.write-to-statsd 1 
settings put global persist.device_config.runtime_native.usap_pool_size_max 0 
settings put global persist.device_config.runtime_native.use_app_image_startup_cache 1 
settings put global persist.device_config.runtime_native_boot.disable_lock_profiling 0 
settings put global persist.device_config.runtime_native_boot.enable_uffd_gc_2 0 
settings put global persist.device_config.runtime_native_boot.iorap_blacklisted_packages 0 
settings put global persist.device_config.runtime_native_boot.iorap_perfetto_enable 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0 
settings put global persist.device_config.runtime_native_boot.iorapd_options 0 
settings put global persist.device_config.tethering.bpf_net_maps_enable_java_bpf_map 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0
}

set_surface > /dev/null 2>&1 

#AndroidConfig
set_android() {
cmd device_config put surfaceflinger refresh_rate 90 
cmd device_config put surfaceflinger max_frame_buffer_acquired_count 3 
cmd device_config put surfaceflinger use_content_detection_for_refresh_rate 1 
cmd device_config put surfaceflinger game_default_frame_rate_override 90  
cmd device_config put surfaceflinger enable_frame_rate_override 0 
cmd device_config put surfaceflinger has_HDR_display 0 
cmd device_config put surfaceflinger supports_background_blur 1 
cmd device_config put surfaceflinger primary_display_orientation 0 
cmd device_config put surfaceflinger force_hwc_copy_for_virtual_displays 0 
cmd device_config put surfaceflinger protected_contents 1 
cmd device_config put surfaceflinger uclamp.min 130 
cmd device_config put surfaceflinger has_wide_color_display 0 
cmd device_config put surfaceflinger use_color_management 0 
cmd device_config put surfaceflinger set_touch_timer_ms 0 
cmd device_config put surfaceflinger max_virtual_display_dimension 4096 
cmd device_config put surfaceflinger wcg_composition_dataspace 143261696 
cmd device_config put surfaceflinger clear_slots_with_set_layer_buffer 0 
cmd device_config put surfaceflinger set_idle_timer_ms 0 
cmd device_config put surfaceflinger set_display_power_timer_ms 0 
cmd device_config put surfaceflinger enable_hwc 0 
cmd device_config put surfaceflinger min_swap_interval 0 
cmd device_config put surfaceflinger disable_expensive_timestamps 1 
cmd device_config put surfaceflinger enable_vds_tweak 0 
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 6300000 
cmd device_config put surfaceflinger vsync_sfoffset_ns 6300000 
cmd device_config put surfaceflinger enable_debug_sf_vs 0 
}
set_android > /dev/null 2>&1 
set_touch() {
settings put systemui min_refresh_rate_for_fps_boost 144 
settings put systemui max_refresh_rate_for_fps_boost 144 
settings put systemui peak_refresh_rate 144.0 
settings put systemui min_refresh_rate 144.0 
settings put system min_refresh_rate_for_fps_boost 144 
settings put system max_refresh_rate_for_fps_boost 144 
settings put system peak_refresh_rate 144.0 
settings put system min_refresh_rate 144.0 
settings put systemui tran_need_recovery_refresh_mode 144 
settings put systemui last_tran_refresh_mode_in_refresh_setting 144 
settings put systemui tran_refresh_mode 144 
settings put system tran_need_recovery_refresh_mode 144 
settings put system last_tran_refresh_mode_in_refresh_setting 144 
settings put system tran_refresh_mode 144 
settings put global burn_in_protection 0 
}

set_touch > /dev/null 2>&1 

#Tweaks
set_surface() {
setprop debug.touchscreen.latency.scale 1,0
setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 144 
setprop debug.hwui.profile.maxframes 144 
setprop debug.javafx.animation.fullspeed 1 
setprop debug.javafx.animation.framerate 144 
setprop debug.redroid.fps 144 
setprop debug.sf.hwc_hotplug_error_via_neg_vsync 1 
setprop debug.sf.hwc_hdcp_via_neg_vsync 1 
setprop debug.sf.set_binder_thread_rt 1 
setprop debug.sf.showcpu 0 
setprop debug.sf.showupdates 0 
setprop debug.sf.showbackground 0 
setprop debug.sf.showfps 0 
setprop debug.sf.hw 0 
setprop debug.sf.enable_hgl 0 
setprop debug.sf.ddms 1 
setprop debug.sf.dump 0 
setprop debug.sf.set_idle_timer_ms 0 
setprop debug.sf.treat_170m_as_sRGB 0 
setprop debug.sf.max_igbp_list_size 0 
setprop debug.sf.disable_hwc_vds 1 
setprop debug.sf.enable_egl_image_tracker 0 
setprop debug.sf.luma_sampling 1 
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_advanced_sf_phase_offset 0 
setprop debug.sf.enable_gl_backpressure 0 
setprop debug.sf.disable_backpressure 1 
setprop debug.sf.latch_unsignaled 0 
setprop debug.sf.gpu_freq_index 7 
setprop debug.sf.auto_latch_unsignaled 0 
setprop debug.sf.enable_hwc_vds 0 
setprop debug.sf.show_predicted_vsync 0 
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.kernel_idle_timer_update_overlay 1 
setprop debug.sf.support_kernel_idle_timer_enabled 0 
setprop debug.sf.vsync_reactor_ignore_present_fences 0 
setprop debug.sf.enable_transaction_tracing 0 
setprop debug.sf.use_phase_offsets_as_durations 0 
setprop debug.sf.ignore_hwc_physical_display_orientation 0 
setprop debug.sf.enable_adpf_cpu_hint 1 
setprop debug.sf.frame_rate_multiple_threshold 144 
setprop debug.sf_frame_rate_multiple_fences 144 
setprop debug.sf.early.app.duration 20000000 
setprop debug.sf.early.sf.duration 27600000 
setprop debug.sf.hwc.min.duration 23000000 
setprop debug.sf.late.app.duration 20000000 
setprop debug.sf.late.sf.duration 27600000 
setprop debug.sf.earlyGl.sf.duration 27600000 
setprop debug.sf.144_fps.early.app.duration 8333333 
setprop debug.sf.144_fps.early.sf.duration 11500000 
setprop debug.sf.144_fps.earlyGl.app.duration 8333333 
setprop debug.sf.144_fps.earlyGl.sf.duration 11500000 
setprop debug.sf.144_fps.late.app.duration 8333333 
setprop debug.sf.144_fps.late.sf.duration 11500000 
setprop debug.sf.high_fps.early.app.duration 10000000 
setprop debug.sf.high_fps.early.sf.duration 13800000 
setprop debug.sf.high_fps.earlyGl.app.duration 10000000 
setprop debug.sf.high_fps.earlyGl.sf.duration 13800000 
setprop debug.sf.high_fps.late.app.duration 10000000 
setprop debug.sf.high_fps.late.sf.duration 13800000 
setprop debug.sf.high_fps.hwc.min.duration 8500000 
setprop debug.sf.high_fps_early_phase_offset_ns 6100000 
setprop debug.sf.high_fps_early_gl_phase_offset_ns 650000 
setprop debug.sf.high_fps_late_app_phase_offset_ns 100000 
setprop debug.sf.earlyGl.app.duration 20000000 
setprop debug.sf.early_gl_phase_offset_ns 3000000 
setprop debug.sf.early_gl_app_phase_offset_ns 15000000 
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000 
setprop debug.sf.early_phase_offset_ns 500000 
}
set_surface > /dev/null 2>&1 
#Setprop
#Number 190283 Credits 

#Surface Flinger
set_surface() {
properties=(
  "debug.sf.disable_backpressure 1"
  "debug.sf.hwc_hotplug_error_via_neg_vsync 1"
  "debug.sf.hwc_hdcp_via_neg_vsync 1"
  "debug.sf.set_binder_thread_rt 1"
  "debug.sf.gpu_freq_index 7"
  "debug.sf.ignore_hwc_physical_display_orientation 0"
  "debug.sf.enable_adpf_cpu_hint 1"
  "debug.sf.latch_unsignaled 0"
  "debug.sf.enable_hwc_vds 0"
  "debug.sf.disable_hwc_vds 1"
  "debug.sf.frame_rate_multiple_threshold 144"
  "debug.sf_frame_rate_multiple_fences 144"
  "debug.sf.enable_egl_image_tracker 0"
  "debug.sf.luma_sampling 1"
  "debug.sf.early_phase_offset_ns 500000"
  "debug.sf.auto_latch_unsignaled 0"
  "debug.sf.early.app.duration 20000000"
  "debug.sf.early.sf.duration 27600000"
  "debug.sf.earlyGl.app.duration 20000000"
  "debug.sf.earlyGl.sf.duration 27600000"
  "debug.sf.late.app.duration 20000000"
  "debug.sf.late.sf.duration 27600000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.hwc.min.duration 23000000"
  "debug.sf.enable_gl_backpressure 0"
  "debug.sf.enable_transaction_tracing false"
  "debug.sf.enable_hgl 0"
  "debug.sf.ddms 1"
  "debug.sf.dump 0"
  "debug.sf.max_igbp_list_size 0"
  "debug.sf.showupdates 0"
  "debug.sf.showcpu 0"
  "debug.sf.showbackground 0"
  "debug.sf.showfps 0"
  "debug.sf.hw 0"
  "debug.sf.disable_client_composition_cache 1"
  "debug.sf.enable_advanced_sf_phase_offset 0"
  "debug.sf.use_phase_offsets_as_durations 0"
  "debug.sf.predict_hwc_composition_strategy 0"
  "debug.sf.treat_170m_as_sRGB 0"
  "debug.sf.set_idle_timer_ms 0"
  "debug.sf.early_gl_phase_offset_ns 3000000"
  "debug.sf.early_gl_app_phase_offset_ns 15000000"
  "debug.sf.high_fps_early_phase_offset_ns 6100000"
  "debug.sf.high_fps_early_gl_phase_offset_ns 650000"
  "debug.sf.high_fps_late_app_phase_offset_ns 100000"
  "debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000"
  "debug.sf.144_fps.early.app.duration 8333333"
  "debug.sf.144_fps.early.sf.duration 11500000"
  "debug.sf.144_fps.earlyGl.app.duration 8333333"
  "debug.sf.144_fps.earlyGl.sf.duration 11500000"
  "debug.sf.144_fps.late.app.duration 8333333"
  "debug.sf.144_fps.late.sf.duration 11500000"
  "debug.sf.high_fps.late.sf.duration 13800000"
  "debug.sf.high_fps.late.app.duration 10000000"
  "debug.sf.high_fps.early.sf.duration 13800000"
  "debug.sf.high_fps.early.app.duration 10000000"
  "debug.sf.high_fps.earlyGl.sf.duration 13800000"
  "debug.sf.high_fps.earlyGl.app.duration 10000000"
  "debug.sf.high_fps.hwc.min.duration 8500000"
)

for prop in "${properties[@]}"; do
  setprop $prop
done
}
set_surface > /dev/null 2>&1 

#Other
(
  settings put global window_animation_scale 1,0 
  settings put global transition_animation_scale 1,0 
  settings put global animator_duration_scale 1,0 
)> /dev/null 2>&1 

set_surface() {
settings put surfaceflinger refresh_rate 144 
settings put surfaceflinger max_frame_buffer_acquired_count 3 
settings put surfaceflinger use_content_detection_for_refresh_rate 1  
settings put surfaceflinger game_default_frame_rate_override 144 
settings put surfaceflinger enable_frame_rate_override 0  
settings put surfaceflinger has_HDR_display 0 
settings put surfaceflinger supports_background_blur 1 
settings put surfaceflinger primary_display_orientation 0  
settings put surfaceflinger force_hwc_copy_for_virtual_displays 0 
settings put surfaceflinger protected_contents 1  
settings put surfaceflinger uclamp.min 130 
settings put surfaceflinger has_wide_color_display 0 
settings put surfaceflinger use_color_management 0 
settings put surfaceflinger set_touch_timer_ms 0 
settings put surfaceflinger max_virtual_display_dimension 4096 
settings put surfaceflinger wcg_composition_dataspace 143261696 
settings put surfaceflinger clear_slots_with_set_layer_buffer 0 
settings put surfaceflinger set_idle_timer_ms 0 
settings put surfaceflinger set_display_power_timer_ms 0 
settings put surfaceflinger enable_hwc 0 
settings put surfaceflinger min_swap_interval 0 
settings put surfaceflinger disable_expensive_timestamps 1 
settings put surfaceflinger enable_vds_tweak 0 
settings put surfaceflinger vsync_eventphase_offset_ns 6300000 
settings put surfaceflinger vsync_sfoffset_ns 6300000 
settings put surfaceflinger enable_debug_sf_vs 0 
sertings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.sampling_profiler 1
settings put global persist.sys.scrollingcache 2 
settings put global persist.sys.fps_unlock_allowed 144 
settings put global sys.fps_unlock_allowed 144 
settings put global persist.sys.ui.hw 1 
settings put global persist.sys.perf.topAppRenderThreadBoost.enable 1 
settings put global persist.device_config.surface_flinger_native_boot.SkiaTracingFeature__use_skia_tracing 0 
settings put global persist.sys.ui.hw 1 
settings put global persist.vendor.color.matrix 2 
settings put global persist.sys.minfree_6g 16384,20480,32768,131072,230400,286720 
settings put global persist.sys.minfree_8g 16384,20480,32768,131072,384000,524288 
settings put global persist.sys.minfree_12g 16384,20480,131072,384000,524288,819200 
settings put global persist.sys.minfree_def 16384,20480,32768,131072,230400,286720 
settings put global persist.vendor.qti.inputopts.enable 1 
settings put global persist.vendor.qti.inputopts.movetouchslop 1 
settings put global persist.sys.NV_FPSLIMIT 144 
settings put global persist.sys.NV_POWERMODE 1 
settings put global persist.sys.NV_PROFVER 15 
settings put global persist.sys.NV_STEREOCTRL 0 
settings put global persist.sys.NV_STEREOSEPCHG 0 
settings put global persist.sys.NV_STEREOSEP 20 
settings put global persist.dev.pm.dyn_samplingrate 1 
settings put global persist.device_config.runtime_native.usap_pool_enabled 1 
settings put global persist.device_config.nnapi_native.current_feature_level 7 
settings put global persist.device_config.nnapi_native.telemetry_enable 0 
settings put global persist.device_config.runtime_native.metrics.reporting-mods 2 
settings put global persist.device_config.runtime_native.metrics.reporting-mods-server 2 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods 100 
settings put global persist.device_config.runtime_native.metrics.reporting-num-mods-server 100 
settings put global persist.device_config.runtime_native.metrics.reporting-spec 1,5,30,60,600 
settings put global persist.device_config.runtime_native.metrics.reporting-spec-server 1,10,60,3600,*
settings put global persist.device_config.runtime_native.metrics.write-to-statsd 1 
settings put global persist.device_config.runtime_native.usap_pool_size_max 0 
settings put global persist.device_config.runtime_native.use_app_image_startup_cache 1 
settings put global persist.device_config.runtime_native_boot.disable_lock_profiling 0 
settings put global persist.device_config.runtime_native_boot.enable_uffd_gc_2 0 
settings put global persist.device_config.runtime_native_boot.iorap_blacklisted_packages 0 
settings put global persist.device_config.runtime_native_boot.iorap_perfetto_enable 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0 
settings put global persist.device_config.runtime_native_boot.iorapd_options 0 
settings put global persist.device_config.tethering.bpf_net_maps_enable_java_bpf_map 0 
settings put global persist.device_config.runtime_native_boot.iorap_readahead_enable 0
}

set_surface > /dev/null 2>&1 

#AndroidConfig
set_android() {
cmd device_config put surfaceflinger refresh_rate 144 
cmd device_config put surfaceflinger max_frame_buffer_acquired_count 3 
cmd device_config put surfaceflinger use_content_detection_for_refresh_rate 1 
cmd device_config put surfaceflinger game_default_frame_rate_override 144  
cmd device_config put surfaceflinger enable_frame_rate_override 0 
cmd device_config put surfaceflinger has_HDR_display 0 
cmd device_config put surfaceflinger supports_background_blur 1 
cmd device_config put surfaceflinger primary_display_orientation 0 
cmd device_config put surfaceflinger force_hwc_copy_for_virtual_displays 0 
cmd device_config put surfaceflinger protected_contents 1 
cmd device_config put surfaceflinger uclamp.min 130 
cmd device_config put surfaceflinger has_wide_color_display 0 
cmd device_config put surfaceflinger use_color_management 0 
cmd device_config put surfaceflinger set_touch_timer_ms 0 
cmd device_config put surfaceflinger max_virtual_display_dimension 4096 
cmd device_config put surfaceflinger wcg_composition_dataspace 143261696 
cmd device_config put surfaceflinger clear_slots_with_set_layer_buffer 0 
cmd device_config put surfaceflinger set_idle_timer_ms 0 
cmd device_config put surfaceflinger set_display_power_timer_ms 0 
cmd device_config put surfaceflinger enable_hwc 0 
cmd device_config put surfaceflinger min_swap_interval 0 
cmd device_config put surfaceflinger disable_expensive_timestamps 1 
cmd device_config put surfaceflinger enable_vds_tweak 0 
cmd device_config put surfaceflinger vsync_eventphase_offset_ns 6300000 
cmd device_config put surfaceflinger vsync_sfoffset_ns 6300000 
cmd device_config put surfaceflinger enable_debug_sf_vs 0 
}
set_android > /dev/null 2>&1 
(
settings put system MOUSEX_AIM_LEVEL 100%
settings put system MOUSE_AIM_SENSITIVTY_SWITCH true
settings put system MOUSE_FILTERING 0.0
settings put system MOUSE_GRADUALLY_SWITCH_WHILE_AIMING true
settings put system MOUSE_SENSITIVITY 100.50
settings put system MOUSE_SMOOTHING ENABLE
settings put system MOUSE_SWITCH_AFTER_AIM_ANIMATION_ENDS true
settings put system MOUSE_SWITCH_IMIDIATELLY_AIMING_STARTS true
settings put system MOUSE_VERTICAL_SENSITIVITY_MULTIPLIER 100.15
settings put system MOUSEX_ef_variadic_parameters co-ordinate
settings put system MOUSE_gestures ASCII
settings put system MultitouchMinDistance 1px
settings put system MultitouchSettleInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system DisplayCutoutEmulationCornerOverlay.velocity 000.1
settings put system DisplayCutoutEmulationWaterfallOverlay true
settings put system DisplayCutoutEmulationCornertouchScreen 1
settings put system DisplayCutoutEmulationDoubleOverlay true
settings put system DisplayCutoutEmulationHoleOverlay Scroll_fixed
settings put system PointerGesture speed
settings put system PointerVelocityControlParameters 1
settings put system PowerbuttonTapping 0
settings put system PressureForID 1
settings put system SensitivyX AimBot
settings put system Set_gestures OEM
settings put system Slide_control_screen light
settings put system settings put system Swipe tftype4
settings put system SwipeMaxWidthRatio 1
settings put system SwipeTransitionAngleCosine 5.0
settings put system TOUCH.POINT.CALIBRATION OEM
settings put system TOUCH.PRESSURE.CALIBRATION performance
settings put system TOUCH.PRESSURE.CELEBRATION performance
settings put system TOUCH.SIZE.CALIBRATION geometric
settings put system TOUCH.SPEED.CALIBRATION adapt
settings put system TOUCH.TXT.CALIBRATION performance
settings put system TOUCH_DIRECTINAL_AIMING 100
settings put system TOUCH_DUMMY Bots
settings put system TOUCH_FreeLook 100
settings put system TapDrag tftype4
settings put system TapInterval 0.1ms
settings put system TapSlop tftype4
settings put system TOUCHAndHold OEM
settings put system TOUCHCount 100
settings put system TOUCH_Heldinterval_Count auto
settings put system TOUCHscreen_threshold 9
settings put system TransformGesture Game_objetc
settings put system VIB_FEEDBACK_MAGNITUDE 0
settings put system VirtualKeyQuietTime 0
settings put system ZoomSpeedRatio 1
settings put system af.resampler.quality 255
settings put system ro.sf.sample_size 2
settings put system ro.surface_flinger.has_HDR_display false
settings put system ro.surface_flinger.has_wide_color_display false
settings put system ro.surface_flinger.max_events_per_sec 300
settings put system ro.surface_flinger.max_frame_buffer_acquired_buffers 3
settings put system ro.surface_flinger.running_without_sync_framework true
settings put system ro.surface_flinger.set_idle_timer_ms 100
settings put system ro.surface_flinger.set_touch_timer_ms 50
settings put system ro.surface_flinger.use_color_management true
settings put system ro.surfaceflinger.hardwareacceleration 1
settings put system ro.sys.fw.dex2oat_thread_count 4
settings put system ro.sys.sdcardfs true
settings put system ro.sys_fw.use_mlc 1
settings put system ro.sys_fw.use_power_workqueues 1
settings put system ro.sys_fw_use_power_saving_animations true
settings put system ro.sys_fw_use_sched_mc_power_savings 1
settings put system ro.sys_fw_use_smart_battery true
settings put system ro.sys_power_mode 1
settings put system ro.telephony.call_ring.delay 0
settings put system ro.treble.enabled false
settings put system touch.accelerate.hw 1
settings put system touch.accelerated.hw 1
settings put system touch.assistant.enabled 0
settings put system touch.coverage.cabration box
settings put system touch.coverage.calibration tftype4
settings put system touch.deviceType touchScreen
settings put system touch.distance.calibration tftype4
settings put system touch.distance.scale physical
settings put system touch.filter.level 2
settings put system touch.filter.path /system/lib/touchfilter/tftype4.so
settings put system touch.filter.tftype4.AccDrag interpolated
settings put system touch.filter.tftype4.AccSize 8
settings put system touch.filter.tftype4.AddInitialAcc 1
settings put system touch.filter.tftype4.AssumedDelayFactorA -11.71
settings put system touch.filter.tftype4.AssumedDelayFactorB 10.53
settings put system touch.filter.tftype4.AssumedDelayFactorC -0.81
settings put system touch.filter.tftype4.DefaultInitialAcc 0
settings put system touch.filter.tftype4.DirectivePriorityFactor 0.9
settings put system touch.filter.tftype4.DragRangeSize 3
settings put system touch.filter.tftype4.Enabled 1
settings put system touch.filter.tftype4.GapResolver 0.9
settings put system touch.filter.tftype4.LatestSpeedWeight 0.12
settings put system touch.filter.tftype4.MaxNumTouch 10
settings put system touch.filter.tftype4.MaxSpeed 0.055
settings put system touch.filter.tftype4.NoAccDistanceMax 950.0
settings put system touch.filter.tftype4.NoAccDistanceMin 15.0
settings put system touch.filter.tftype4.NoAccRate 0.3
settings put system touch.filter.tftype4.OrgSize 8
settings put system touch.filter.tftype4.PStablePositionFactor 0
settings put system touch.filter.tftype4.PositionFactorA 0.2
settings put system touch.gestureMode pointer
settings put system touch.gesture_mode spots
settings put system touch.input_flinger.calibration physical
settings put system touch.isHardware.accelerated true
settings put system touch.isHw 1
settings put system touch.orientation.calibration tftype4
settings put system touch.orientationAware 1
settings put system touch.pressure.calibration amplitude
settings put system touch.pressure.scale 0.0125
settings put system touch.pressure.source touchScreen
settings put system touch.scale 5
settings put system touch.scroll.calibration physical
settings put system touch.size.bias -13.924837
settings put system touch.size.calibration diameter
settings put system touch.size.isSummed 0
settings put system touch.size.scale 32.69
settings put system touch.speed.calibration speed
settings put system touch.surface_flinger.calibration physical
settings put system touch.toolSize.areaBias 0
settings put system touch.toolSize.areaScale 1
settings put system touch.toolSize.calibration geometric
settings put system touch.toolSize.isSummed 0
settings put system touch.toolSize.linearBias 0
settings put system touch.toolSize.linearScale 1
settings put system touch.touchSize.calibration geometric
settings put system touch.txt.calibration speed
settings put system touchCount 100
settings put system touch_FreeLook 100
settings put system touch_action pan_x
settings put system touch_boost 1
settings put system touch_click_start 0.01
settings put system touch_directinal_aiming 100
settings put system touch_fixed_sensitivity true
settings put system touch_leave fast
settings put system touch_oem true
settings put system touch_speed 100
settings put system touch_stocks OEM
settings put system touchboost 1
settings put system touchscreen_double_tap_speed 100
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_hovering 0
settings put system touchscreen_min_press_time 30
settings put system touchscreen_pointer_speed 100
settings put system touchscreen_pressure_calibration 4096
settings put system touchscreen_sensitivity 100
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_sensitivity_scale 99.9
settings put system touchswipedeadzone 5
settings put system tty_mode 0
settings put system touch.toolSize.areaScale 22
settings put system touch.toolSize.areaBias 0
settings put system touch.toolSize.linearScale 9.2
settings put system touch.toolSize.linearBias 0
settings put system TapDragInterval 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
settings put system VirtualKeyQuietTime 0
settings put system acceleration 2527200
settings put system ZoomSpeedRatio 1
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system SwipeTransitionAngleCosine 3.6
settings put system DragMinSwitchSpeed 2527200
settings put system MultitouchMinDistance 1px
settings put system MultitouchSettleInterval 0.1ms
settings put system TapInterval 0.1ms
settings put system TapSlop 1px
settings put system touch.coverage.calibration geometric
settings put system touch.deviceType touchScreen
settings put system touch.distance.calibration geometric
settings put system touch.distance.scale 0
settings put system touch.gestureMode spots
settings put system touch.orientation.calibration geometric
settings put system touch.pressure.calibration geometric
settings put system touch.size.calibration geometric
settings put system touch.size.isSummed 0
settings put system touch.size.scale 1
settings put system touch.speed.calibration geometric
settings put system touch.txt.calibration geometric
settings put system touch_directinal_aiming 100
settings put system touch.assistant.enabled 0
settings put system touchCount 100
settings put system touch_FreeLook 100
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system adaptive_touch_sensitivity 1
settings put system PointerGesture true
settings put system PointerVelocityControlParameters  1
settings put system PowerbuttonTapping 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put global preferred_network_mode 9
settings put global wifi_sleep_policy 2
settings put global tether_dun_required 0
settings put global stay_on_while_plugged_in 3
settings put system radio.data_stall_treshold 1
settings put system radio.sib11_thresh 31
settings put system radio.better_ps_reception 1
settings put global preferred_network_mode 12
settings put system radio.sib1_thresh 31
settings put system radio.sib3_thresh 31
settings put system radio.sib16_thresh 31
settings put secure allow_heat_cooldown_schedule true
settings put secure allow_heat_cooldown_always 1
settings put secure heat_cooldown_schedule 5s
settings put secure allow_more_heat_value 30
)> /dev/null 2>&1
#versi1
(
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
setprop debug.performance.tuning 1
settings put system view.scroll_friction 0
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1
setprop debug.sf.set_touch_timer_ms 100
setprop debug.MultitouchSettleInterval 0.01ms
setprop debyg.MultitouchMinDistance 0.01px
setprop debug.TapInterval 0.1ms
settings put global fw.bservice_enable true
settings put global fw.bg_apps_limit 4
settings put global fw.bservice_limit 4
settings put global fw.bservice_age 10000
setprop debug.touch.pressure.scale 0.001
setprop debug.touch_move_opt 1
setprop debug.touch_vsync_opt 1
setprop debug.touch.size.bias 0
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put system pointer_speed 7
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_pointer_speed 15
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.scale auto
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.gesturemode spots
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system view.touch_slop 0dp
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.3
) > /dev/null 2>&1

#versi 2
(
setprop debug.touch.size.bias 0
setprop debug.MultitouchSettleInterval 1ms
setprop debug.TapInterval 1ms
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
settings put system view.scroll_friction 0.0001
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put system pointer_speed 7
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_pointer_speed 15
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.scale auto
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.pressure.scale 0.0001
settings put system touch.gesturemode spots
settings put system MultitouchMinDistance auto
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system view.touch_slop 0dp
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system view.touch_slop 5
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
settings put global window_animation_scale 0.3
settings put global transition_animation_scale 0.3
settings put global animator_duration_scale 0.3
) > /dev/null 2>&1
(
settings put global touch.pressure.scale 0.1
settings put global touch.size.scale 0.1
settings put global transition_animation_scale 0
settings put global window_animation_scale 0
settings put global settings_enable_monitor_phantom_procs false
settings put system pointer_speed 5
settings put global surface_flinger.set_idle_timer_ms 0
settings put global surface_flinger.set_touch_timer_ms 0
settings put global surface_flinger.set_display_power_timer_ms 0
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.multithreaded_present true
settings put global surface_flinger.use_context_priority 1
) > /dev/null 2>&1

(
#V19
settings put system touch_sampling_rate 120
settings put system touch_size_calibration geometric
settings put system touch_stats {"min":1,"max":1}
settings put system touchX_debuggable 1
settings put system touch_boost_threshold 5
settings put system touch_feature_gamemode_enable 1
settings put system touch_input_sensitivity 1
settings put system touch_rate_control 0
settings put system touch_response_rate 1
settings put system touch_sampling_rate_override 1
settings put system touch_sensitivity 1_2
settings put system touch_slop 8
settings put system touch_switch_set_touchscreen 14005
settings put system touch_tap_sensitivity 1
settings put system touchpanel_game_switch_enable 1
) > /dev/null 2>&1

(
#V18
settings put global surface_flinger.start_graphics_allocator_service true
settings put global surface_flinger.running_without_sync_framework true
setprop debug.sf.luma_sampling 0
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 0
setprop debug.sf.enable_layer_caching 0
setprop debug.sf.disable_client_composition_cache 1 
setprop debug.sf.enable_gl_backpressure false
setprop debug.sf.enable_hwc_vds 0
setprop debug.sf.hw 0
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.use_phase_offsets_as_durations 1
#V17SCREEN.TOUCH
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.late.sf.duration 10500000
setprop debug.sf.late.app.duration 16600000
setprop debug.sf.treat_170m_as_sRGB 1
setprop debug.sf.earlyGl.app.duration 16600000
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.boot.fps 20
#V16 Faster Touch 
setprop debug.performance.tuning 1
settings put system view.scroll_friction 0
settings put global windowsmgr.support_low_latency_touch true
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
settings put system haptic_feedback_intensity 50
settings put global tactile_feedback_enabled 1
debug.sf.set_touch_timer_ms 100
###
setprop debug.MultitouchSettleInterval 0.01ms
setprop debyg.MultitouchMinDistance 0.01px
setprop debug.TapInterval 0.1ms
settings put global fw.bservice_enable true
settings put global fw.bg_apps_limit 4
settings put global fw.bservice_limit 4
settings put global fw.bservice_age 10000
setprop debug.touch.pressure.scale 0.001
setprop debug.touch_move_opt 1
setprop debug.touch_vsync_opt 1
setprop debug.touch.size.bias 0 
setprop debug.TapSlop1px
settings put global windowsmgr.max_events_per_sec 180
settings put global min_pointer_dur 8
settings put global product.multi_touch_enabled true
settings put global securestorage.knox false
setprop debug.security.mdpp none
setprop debug.security.mdpp.result none
settings put system af.resampler.quality 255
settings put system scrollingcache 3
setprop debug.service.lgospd.enable 0
setprop debug.service.pcsync.enable 0
setprop debug.touch.deviceTypetouchScreen
cmd device_config put input default_key_press_repeat_rate 33
cmd device_config put input filtered_accel_event_rate_hz 240
cmd device_config put input touch_screen_sample_interval_ms 8
cmd device_config put systemui cg_frame_interval_millis 4
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui low_power_refresh_rate_millis 0
cmd device_config put systemui cg_max_frame_skip 8
settings put system service.touch.tpf 30
settings put system lowThreshold 0
settings put system highThreshold 0
settings put system VirtualKeyQuietTime 0
settings put system KeyRepeatDelay 0
settings put system KeyRepeatTimeout 0
setprop debug.boosterorientnosync 1
settings put global sf.disable_smooth_effect true
settings put secure touch_distance_scale 0
settings put secure view_scroll_friction 0
settings put secure multi_touch_enabled 1
settings put secure assist_touch_gesture_enabled 0
settings put global maximum_obscuring_opacity_for_touch 0.5
settings put system show_touches 0
settings put global block_untrusted_touches 0
settings put system vsync.disable.fps.limit 1
settings put system table.framerate 120
setprop debug.touch.deviceType touchScreen
settings put system disable.hwc.delay 1
settings put system Touc_xRotation  360
settings put system touchswipedeadzone 5
settings put secure long_press_timeout 300
settings put secure multi_press_timeout 300
settings put secure touch_size_scale 5
settings put secure show_rotation_suggestions 0
settings put secure touch_size_bias 5
settings put secure touch_exploration_enabled 1
settings put secure touch_orientationAware 1
settings put secure touch_pressure_scale 0.00000125
settings put system touchscreen_hovering 0
settings put system touchscreen_sensitivity_mode 3
settings put system touchscreen_pressure_calibration 1023
settings put system touchscreen_threshold 9
settings put system touchfeature.gamemode.enable true
settings put system r.setframepace 120
settings put system touch_switch_set_touchscreen 14005
settings put system touchpanel_game_switch_enable 1
settings put system touchpanel_oppo_tp_direction 1
settings put system touchpanel_oppo_tp_limit_enable 0
settings put system touchpanel_oplus_tp_limit_enable 0
settings put system touchpanel_oplus_tp_direction 1
settings put system use_dithering 0
settings put system use_dithering false
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.1
settings put global DragMinSwitchSpeed 99999.0px/s
settings put global SwipeMaxWidthRatio 1
settings put system MovementSpeedRatio 1
settings put system ZoomSpeedRatio 1
settings put system SwipeTransitionAngleCosine 3.6
settings put system mot.proximity.distance 1
settings put system PointerVelocityControlParameters 1
settings put system device.internal 1
setprop debug.performance.tuning 1
setprop debug.egl.swapinterval 90
settings put secure dev.pm.dyn_samplingrate 1
settings put system touchscreen_sensitivity 10
settings put system touchscreen_min_press_time 50
settings put system touchscreen_hevoring 0
settings put system touchscreen_gesture_mode 1
settings put system touchscreen_sensitivity_threshold 9
settings put system touchscreen_double_tap_speed 75
settings put system touchscreen_sensitivity_scale 1.5
settings put system qti.inputopts.enable true
settings put system qti.inputopts.movetouchslop 0.6
settings put system touch.orientationAware 1
settings put system SurfaceOrientation auto
settings put system touch.size.calibration geometric
settings put system touch.size.isSummed 1
settings put system touch.orientation.calibration auto
settings put system touch.distance.scale auto
settings put system touch.coverage.calibration octagram
settings put system touch.gesturemode spots
settings put system MovementSpeedRatio auto
settings put system pm.dyn_samplingrate 9999999999999999999999999999
settings put system touch.pressure.calibration auto
settings put system scroll.accelerated.hw true
settings put system ui.hwframes 9999999999999999999999999999
settings put system force_high_end_gfx 1
settings put system sf.disable_smooth_effect true
settings put system max_num_touch auto
settings put system maxeventspersec 9999999999999999999999999999
settings put system resampler.quality 255
settings put system touch.sampling rate 720
settings put system adaptive_touch_sensitivity speed
settings put system touch.orientationAware 0
settings put system PressureForID 0.01
settings put system QuietInterval 0.1ms
settings put system MultitouchMinDistance 1px
settings put system AIM_SENSITIVITY_TRANSITION_TIME GRADUAL
settings put system APP_SWITCH_DELAY_TIME false
settings put system AbsoluteXForID SpeedForID
settings put system AccelerationX true
settings put system AccelerationY true
settings put system DoubleTouch OEM
settings put system PowerbuttonTapping 0
settings put system touch.assistant.enabled 0
settings put system type.touch_speed true
settings put system MovementSpeedRatio 0.8
settings put system accuracy.control 100
settings put system view_scroll_friction 10
settings put secure multi_press_timeout 300
settings put global KeyRepeatDelay 0
settings put global KeyRepeatTimeout 0
settings put global LOSS_OF_FOCUS_BY_MOUSE_MOVEMENT DISABLED
settings put global MOUSEX_AIM_LEVEL 95%
) > /dev/null 2>&1
echo "Unpacking Zip File"
echo ""
sleep 2
echo "Membuat Storage Database Module"
sleep 3
echo "Instalasi Module Sukses"
echo ""
sleep 2