echo "╔╦╗ ╔═╗ ╦┈╦ ╔═╗ ╦┈╦  
┈║┈ ║┈║ ║┈║ ║┈┈ ╠═╣  
┈╩┈ ╚═╝ ╚═╝ ╚═╝ ╩┈╩  
╦ ╔═╗ ╔═╗  
║ ║┈║ ╚═╗  
╩ ╚═╝ ╚═╝  
"
echo ""
echo "uninstall Touch ios v2.4 Please Waite"
echo ""
(
settings delete system MOUSEX_AIM_LEVEL
settings delete system MOUSE_AIM_SENSITIVTY_SWITCH
settings delete system MOUSE_FILTERING
settings delete system MOUSE_GRADUALLY_SWITCH_WHILE_AIMING
settings delete system MOUSE_SENSITIVITY
settings delete system MOUSE_SMOOTHING
settings delete system MOUSE_SWITCH_AFTER_AIM_ANIMATION_ENDS
settings delete system MOUSE_SWITCH_IMIDIATELLY_AIMING_STARTS
settings delete system MOUSE_VERTICAL_SENSITIVITY_MULTIPLIER 
settings delete system MOUSEX_ef_variadic_parameters co-ordinate
settings delete system MOUSE_gestures
settings delete system MultitouchMinDistance
settings delete system MultitouchSettleInterval 
settings delete system MultitouchMinDistance
settings delete system DisplayCutoutEmulationCornerOverlay.velocity
settings delete system DisplayCutoutEmulationWaterfallOverlay
settings delete system DisplayCutoutEmulationCornertouchScreen
settings delete system DisplayCutoutEmulationDoubleOverlay 
settings delete system DisplayCutoutEmulationHoleOverlay
settings delete system PointerGesture
settings delete system PointerVelocityControlParameters
settings delete system PowerbuttonTapping
settings delete system PressureForID 
settings delete system SensitivyX
settings delete system Set_gestures
settings delete system Slide_control_screen 
settings delete system Swipe 
settings delete system SwipeMaxWidthRatio 
settings delete system SwipeTransitionAngleCosine 
settings delete system TOUCH.POINT.CALIBRATION
settings delete system TOUCH.PRESSURE.CALIBRATION 
settings delete system TOUCH.PRESSURE.CELEBRATION
settings delete system TOUCH.SIZE.CALIBRATION 
settings delete system TOUCH.SPEED.CALIBRATION 
settings delete system TOUCH.TXT.CALIBRATION 
settings delete system TOUCH_DIRECTINAL_AIMING 
settings delete system TOUCH_DUMMY
settings delete system TOUCH_FreeLook
settings delete system TapDrag tftype4
settings delete system TapInterval 
settings delete system TapSlop 
settings delete system TOUCHAndHold
settings delete system TOUCHCount
settings delete system TOUCH_Heldinterval_Count 
settings delete system TOUCHscreen_threshold
settings delete system TransformGesture 
settings delete system VIB_FEEDBACK_MAGNITUDE 
settings delete system VirtualKeyQuietTime 
settings delete system ZoomSpeedRatio
settings delete system af.resampler.quality
settings delete system ro.sf.sample_size
settings delete system ro.surface_flinger.has_HDR_display 
settings delete system ro.surface_flinger.has_wide_color_display 
settings delete system ro.surface_flinger.max_events_per_sec 
settings delete system ro.surface_flinger.max_frame_buffer_acquired_buffers 
settings delete system ro.surface_flinger.running_without_sync_framework 
settings delete system ro.surface_flinger.set_idle_timer_ms
settings delete system ro.surface_flinger.set_touch_timer_ms
settings delete system ro.surface_flinger.use_color_management 
settings delete system ro.surfaceflinger.hardwareacceleration
settings delete system ro.sys.fw.dex2oat_thread_count
settings delete system ro.sys.sdcardfs 
settings delete system ro.sys_fw.use_mlc
settings delete system ro.sys_fw.use_power_workqueues
settings delete system ro.sys_fw_use_power_saving_animations 
settings delete system ro.sys_fw_use_sched_mc_power_savings
settings delete system ro.sys_fw_use_smart_battery 
settings delete system ro.sys_power_mode
settings delete system ro.telephony.call_ring.delay 
settings delete system ro.treble.enabled 
settings delete system touch.accelerate.hw 
settings delete system touch.accelerated.hw 
settings delete system touch.assistant.enabled 
settings delete system touch.coverage.cabration 
settings delete system touch.coverage.calibration 
settings delete system touch.deviceType 
settings delete system touch.distance.calibration 
settings delete system touch.distance.scale 
settings delete system touch.filter.level
settings delete system touch.filter.path
settings delete system touch.filter.tftype4.AccDrag 
settings delete system touch.filter.tftype4.AccSize
settings delete system touch.filter.tftype4.AddInitialAcc 
settings delete system touch.filter.tftype4.AssumedDelayFactorA
settings delete system touch.filter.tftype4.AssumedDelayFactorB 
settings delete system touch.filter.tftype4.AssumedDelayFactorC 
settings delete system touch.filter.tftype4.DefaultInitialAcc 
settings delete system touch.filter.tftype4.DirectivePriorityFactor 
settings delete system touch.filter.tftype4.DragRangeSize 
settings delete system touch.filter.tftype4.Enabled 
settings delete system touch.filter.tftype4.GapResolver 
settings delete system touch.filter.tftype4.LatestSpeedWeight 
settings delete system touch.filter.tftype4.MaxNumTouch 
settings delete system touch.filter.tftype4.MaxSpeed 
settings delete system touch.filter.tftype4.NoAccDistanceMax
settings delete system touch.filter.tftype4.NoAccDistanceMin
settings delete system touch.filter.tftype4.NoAccRate
settings delete system touch.filter.tftype4.OrgSize
settings delete system touch.filter.tftype4.PStablePositionFactor 
settings delete system touch.filter.tftype4.PositionFactorA
settings delete system touch.gestureMode
settings delete system touch.gesture_mode
settings delete system touch.input_flinger.calibration
settings delete system touch.isHardware.accelerated 
settings delete system touch.isHw 
settings delete system touch.orientation.calibration 
settings delete system touch.orientationAware 
settings delete system touch.pressure.calibration 
settings delete system touch.pressure.scale
settings delete system touch.pressure.source 
settings delete system touch.scale
settings delete system touch.scroll.calibration 
settings delete system touch.size.bias
settings delete system touch.size.calibration 
settings delete system touch.size.isSummed 
settings delete system touch.size.scale
settings delete system touch.speed.calibration
settings delete system touch.surface_flinger.calibration
settings delete system touch.toolSize.areaBias 
settings delete system touch.toolSize.areaScale 
settings delete system touch.toolSize.calibration 
settings delete system touch.toolSize.isSummed 
settings delete system touch.toolSize.linearBias 
settings delete system touch.toolSize.linearScale 
settings delete system touch.touchSize.calibration 
settings delete system touch.txt.calibration 
settings delete system touchCount 
settings delete system touch_FreeLook 
settings delete system touch_action 
settings delete system touch_boost 
settings delete system touch_click_start
settings delete system touch_directinal_aiming 
settings delete system touch_fixed_sensitivity 
settings delete system touch_leave 
settings delete system touch_oem 
settings delete system touch_speed 
settings delete system touch_stocks
settings delete system touchboost 
settings delete system touchscreen_double_tap_speed 
settings delete system touchscreen_gesture_mode 
settings delete system touchscreen_hovering 
settings delete system touchscreen_min_press_time 
settings delete system touchscreen_pointer_speed 
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_sensitivity 
settings delete system touchscreen_sensitivity_mode 
settings delete system touchscreen_sensitivity_scale
settings delete system touchswipedeadzone
settings delete system tty_mode 
settings delete system touch.toolSize.areaScale
settings delete system touch.toolSize.areaBias 
settings delete system touch.toolSize.linearScale 
settings delete system touch.toolSize.linearBias 
settings delete system TapDragInterval 
settings delete system KeyRepeatDelay 
settings delete system KeyRepeatTimeout 
settings delete system VirtualKeyQuietTime 
settings delete system acceleration 
settings delete system ZoomSpeedRatio 
settings delete system lowThreshold 
settings delete system highThreshold 
settings delete system SwipeTransitionAngleCosine
settings delete system DragMinSwitchSpeed
settings delete system MultitouchMinDistance
settings delete system MultitouchSettleInterval 
settings delete system TapInterval
settings delete system TapSlop
settings delete system touch.coverage.calibration 
settings delete system touch.deviceType 
settings delete system touch.distance.calibration 
settings delete system touch.distance.scale 
settings delete system touch.gestureMode
settings delete system touch.orientation.calibration 
settings delete system touch.pressure.calibration 
settings delete system touch.size.calibration 
settings delete system touch.size.isSummed 
settings delete system touch.size.scale 
settings delete system touch.speed.calibration 
settings delete system touch.txt.calibration 
settings delete system touch_directinal_aiming 
settings delete system touch.assistant.enabled 
settings delete system touchCount 
settings delete system touch_FreeLook 
settings delete system type.touch_speed 
settings delete system view.touch_slop
settings delete system MovementSpeedRatio
settings delete system accuracy.control 
settings delete system adaptive_touch_sensitivity 
settings delete system PointerGesture 
settings delete system PointerVelocityControlParameters  
settings delete system PowerbuttonTapping 
settings delete system PressureForID 
settings delete system QuietInterval
settings delete global preferred_network_mode
settings delete global wifi_sleep_policy
settings delete global tether_dun_required 
settings delete global stay_on_while_plugged_in 
settings delete system radio.data_stall_treshold 
settings delete system radio.sib11_thresh 
settings delete system radio.better_ps_reception 
settings delete global preferred_network_mode
settings delete system radio.sib1_thresh 
settings delete system radio.sib3_thresh 
settings delete system radio.sib16_thresh 
settings delete secure allow_heat_cooldown_schedule 
settings delete secure allow_heat_cooldown_always 
settings delete secure heat_cooldown_schedule
settings delete secure allow_more_heat_value 
)> /dev/null 2>&1
#versi1
(
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.late.sf.duration ""
setprop debug.sf.late.app.duration ""
setprop debug.sf.treat_170m_as_sRGB ""
setprop debug.sf.earlyGl.app.duration ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.boot.fps ""
setprop debug.performance.tuning ""
settings delete system view.scroll_friction
settings delete global windowsmgr.support_low_latency_touch
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
settings delete system haptic_feedback_intensity
settings delete global tactile_feedback_enabled
setprop debug.sf.set_touch_timer_ms ""
settings delete global fw.bservice_enable
settings delete global fw.bg_apps_limit
settings delete global fw.bservice_limit
settings delete global fw.bservice_age
setprop debug.touch.pressure.scale ""
setprop debug.touch_move_opt ""
setprop debug.touch_vsync_opt ""
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
setprop debug.touch.size.bias
setprop debug.MultitouchSettleInterval
setprop debug.TapInterval
setprop debug.TapSlop
setprop debug.security.mdpp
setprop debug.security.mdpp.result
setprop debug.service.lgospd.enable
setprop debug.service.pcsync.enable
setprop debug.touch.deviceType
setprop debug.boosterorientnosync
setprop debug.performance.tuning
setprop debug.egl.swapinterval
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
settings delete global sf.disable_smooth_effect
settings delete global block_untrusted_touches
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete secure dev.pm.dyn_samplingrate
settings delete system af.resampler.quality
settings delete system scrollingcache
settings delete system show_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete system pointer_speed
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touch_switch_set_touchscreen
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
settings delete system touchscreen_min_press_time
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.scale
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.pressure.scale
settings delete system touch.gesturemode
settings delete system MultitouchMinDistance
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system max_num_touch
settings delete system view.touch_slop
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system touch.sampling_rate
settings delete system adaptive_touch_sensitivity
settings delete system PressureForID
settings delete system QuietInterval
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system accuracy.control
) > /dev/null 2>&1

#versi 2
(
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
setprop debug.touch.size.bias
setprop debug.MultitouchSettleInterval
setprop debug.TapInterval
setprop debug.TapSlop
setprop debug.security.mdpp
setprop debug.security.mdpp.result
setprop debug.service.lgospd.enable
setprop debug.service.pcsync.enable
setprop debug.touch.deviceType
setprop debug.boosterorientnosync
setprop debug.performance.tuning
setprop debug.egl.swapinterval
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
settings delete global sf.disable_smooth_effect
settings delete global block_untrusted_touches
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete secure dev.pm.dyn_samplingrate
settings delete system af.resampler.quality
settings delete system scrollingcache
settings delete system show_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
settings delete system view.scroll_friction
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete system pointer_speed
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touch_switch_set_touchscreen
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
settings delete system touchscreen_min_press_time
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.scale
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.pressure.scale
settings delete system touch.gesturemode
settings delete system MultitouchMinDistance
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system max_num_touch
settings delete system view.touch_slop
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system touch.sampling_rate
settings delete system adaptive_touch_sensitivity
settings delete system PressureForID
settings delete system QuietInterval
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system accuracy.control
) > /dev/null 2>&1
#versi1
(
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.late.sf.duration ""
setprop debug.sf.late.app.duration ""
setprop debug.sf.treat_170m_as_sRGB ""
setprop debug.sf.earlyGl.app.duration ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.boot.fps ""
setprop debug.performance.tuning ""
settings delete system view.scroll_friction
settings delete global windowsmgr.support_low_latency_touch
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
settings delete system haptic_feedback_intensity
settings delete global tactile_feedback_enabled
setprop debug.sf.set_touch_timer_ms ""
settings delete global fw.bservice_enable
settings delete global fw.bg_apps_limit
settings delete global fw.bservice_limit
settings delete global fw.bservice_age
setprop debug.touch.pressure.scale ""
setprop debug.touch_move_opt ""
setprop debug.touch_vsync_opt ""
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
setprop debug.touch.size.bias
setprop debug.MultitouchSettleInterval
setprop debug.TapInterval
setprop debug.TapSlop
setprop debug.security.mdpp
setprop debug.security.mdpp.result
setprop debug.service.lgospd.enable
setprop debug.service.pcsync.enable
setprop debug.touch.deviceType
setprop debug.boosterorientnosync
setprop debug.performance.tuning
setprop debug.egl.swapinterval
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
settings delete global sf.disable_smooth_effect
settings delete global block_untrusted_touches
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete secure dev.pm.dyn_samplingrate
settings delete system af.resampler.quality
settings delete system scrollingcache
settings delete system show_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete system pointer_speed
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touch_switch_set_touchscreen
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
settings delete system touchscreen_min_press_time
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.scale
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.pressure.scale
settings delete system touch.gesturemode
settings delete system MultitouchMinDistance
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system max_num_touch
settings delete system view.touch_slop
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system touch.sampling_rate
settings delete system adaptive_touch_sensitivity
settings delete system PressureForID
settings delete system QuietInterval
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system accuracy.control
) > /dev/null 2>&1

#versi 2
(
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
setprop debug.touch.size.bias
setprop debug.MultitouchSettleInterval
setprop debug.TapInterval
setprop debug.TapSlop
setprop debug.security.mdpp
setprop debug.security.mdpp.result
setprop debug.service.lgospd.enable
setprop debug.service.pcsync.enable
setprop debug.touch.deviceType
setprop debug.boosterorientnosync
setprop debug.performance.tuning
setprop debug.egl.swapinterval
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
settings delete global sf.disable_smooth_effect
settings delete global block_untrusted_touches
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete secure long_press_timeout
settings delete secure multi_press_timeout
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete secure dev.pm.dyn_samplingrate
settings delete system af.resampler.quality
settings delete system scrollingcache
settings delete system show_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
settings delete system view.scroll_friction
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete system pointer_speed
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touch_switch_set_touchscreen
settings delete system touchpanel_game_switch_enable
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
settings delete system touchscreen_min_press_time
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.scale
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.pressure.scale
settings delete system touch.gesturemode
settings delete system MultitouchMinDistance
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system max_num_touch
settings delete system view.touch_slop
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system touch.sampling_rate
settings delete system adaptive_touch_sensitivity
settings delete system PressureForID
settings delete system QuietInterval
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system accuracy.control
) > /dev/null 2>&1
echo "Repacking Zip File"
echo ""
sleep 2
echo "Menghapus Storage Database Module"
sleep 3
echo "uninstall Module Done"
echo ""