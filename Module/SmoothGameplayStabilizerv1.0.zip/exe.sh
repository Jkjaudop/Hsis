settings put global touch_boost 1
settings put global game_touch_response 1
setprop debug.sf.latch_unlocked 1
setprop debug.cpu.driver_use_multicore true
settings put global thermal_throttling 1
setprop persist.sys.power_mode balanced
settings put global settings_enable_monitor_phantom_procs false
settings put global force_gpu_rendering 1
settings put global enable_gpu_debug_layers 0
settings put global game_driver_all_apps_preferred 1
settings put global sched_boost 1
cmd thermalservice override-status 1
settings put global sustained_performance_mode_enabled 1