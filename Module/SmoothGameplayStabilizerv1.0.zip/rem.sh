settings delete global touch_boost
settings delete global game_touch_response
settings delete global thermal_throttling
settings delete global settings_enable_monitor_phantom_procs
settings delete global force_gpu_rendering
settings delete global enable_gpu_debug_layers
settings delete global game_driver_all_apps_preferred
settings delete global sched_boost
settings delete global sustained_performance_mode_enabled
cmd thermalservice reset