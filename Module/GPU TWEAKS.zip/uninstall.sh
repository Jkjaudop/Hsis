#!/system/bin/sh


echo ""
echo "⚙️  Restoring default GPU governor..."
settings delete global gpu.governor
settings delete global persist.sys.gpu.turbo
settings delete global persist.gpu.boost
sleep 1

echo "🎨 Resetting rendering priority..."
settings delete global render_thread.priority
settings delete global surface_flinger.render_intent
sleep 1

echo "🎮 Resetting HWUI properties..."
settings delete global hwui.renderer
settings delete global hwui.drop_shadow_cache_size
settings delete global hwui.gradient_cache_size
settings delete global hwui.layer_cache_size
settings delete global hwui.r_buffer_cache_size
settings delete global hwui.texture_cache_size
sleep 1