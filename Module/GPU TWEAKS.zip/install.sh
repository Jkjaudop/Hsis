#!/system/bin/sh

echo ""
echo "⚙️  Applying GPU Governor to performance..."
settings put global gpu.governor "performance"
settings put global persist.sys.gpu.turbo 1
settings put global persist.gpu.boost 1
sleep 1

echo "🎨 Forcing higher rendering priority..."
settings put global render_thread.priority 1
settings put global surface_flinger.render_intent 1
sleep 1

echo "🎮 Enabling HWUI boosts..."
settings put global hwui.renderer opengl
settings put global hwui.drop_shadow_cache_size 12
settings put global hwui.gradient_cache_size 4
settings put global hwui.layer_cache_size 32
settings put global hwui.r_buffer_cache_size 8
settings put global hwui.texture_cache_size 48
sleep 1