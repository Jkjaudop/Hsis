sleep 1
# Alisin ang Mga Setting ng Refresh Rate at AIM
(
    settings delete system R.integer.config_defaultRefreshRate
    settings delete system PEAK_REFRESH_RATE
    settings delete system R.integer.config_defaultPeakRefreshRate
    settings delete system MIN_REFRESH_RATE
    settings delete system peak.refresh.rate
    settings delete system peak_refresh_rate
    settings delete global surface_flinger.use_content_detection_for_refresh_rate
    settings delete global surface_flinger.set_touch_timer_ms
    settings delete global surface_flinger.set_idle_timer_ms
    settings delete global surface_flinger.set_display_power_timer_ms
    settings delete system display_refresh_mode
    settings delete system min_refresh_rate
    settings delete system user.screen.refresh.rate
    settings delete system user.refresh.rate
    settings delete system user_refresh_rate
    settings delete system user_screen_refresh_rate
    settings delete system custom.game.access.com.pubg.mobile.fps
    settings delete system custom.game.access.com.pubglite.fps
    settings delete system custom.game.access.com.netease.newspike.fps
    settings delete system custom.game.access.com.dts.freefireth.fps
    settings delete system custom.game.access.com.dts.freefiremax.fps
    settings delete system custom.game.access.com.garena.game.codm.fps
    settings delete system custom.game.access.com.activision.callofduty.warzone.fps
    settings delete system pointer.speed
    settings delete system pointer.speed
) >/dev/null 2>&1

# Alisin ang Fix Gyro Delay
(
    settings delete global Sensor.TYPE_ORIENTATION
    settings delete global Sensor.TYPE_ACCELEROMETER
    settings delete global Sensor.TYPE_MAGENTIC_FIELD
    settings delete global SensorManager.getRotationMatrix
    settings delete global SensorManager.getOrientation
    settings delete global Surface.ROTATION
) >/dev/null 2>&1

# Alisin ang Acceleration Tweaks
(
    setprop debug.performance.tuning ""
    setprop debug.enabletr ""
    setprop debug.overlayui.enable ""
    settings delete global config.disable.hw.accel
    settings delete global product.gpu.driver
    settings delete global config.enable.hw.accel
    settings delete global sf.compbypass.enable
    settings delete global sf.blurs.are.expensive
    settings delete global surface.flinger.supports.background.blur
    setprop debug.sf.hw ""
    setprop debug.egl.hw ""
    setprop debug.gralloc.gfx.ubwc.disable ""
    setprop debug.mdpcomp.logs ""
    setprop debug.sf.enable.hwc.vds ""
    setprop debug.sf.enable.gl.backpressure ""
    setprop debug.sf.latch.unsignaled ""
    settings delete system boot.fps
    settings delete global qti.core.ctl.max.cpu
    settings delete global qti.core.ctl.min.cpu
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Sensitivity ng Touch
(
    settings delete system pointer_speed
    settings delete system touch.size.calibration
    settings delete system touch.size.isSummed
    settings delete system touch.size.scale
    settings delete system touch.pressure.calibration
    settings delete system touch.pressure.scale
    settings delete system touch.orientation.calibration
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Latency ng Touch
(
    settings delete global tap_duration
    settings delete global touch.response_time
    settings delete global touch.pressure.threshold
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Input Lag
(
    settings delete global input.lag_reduction_mode
    settings delete global input.lag_compensation_mode
    settings delete global input.reduce_motion_blur
    settings delete global input.reduce_jitter
    settings delete global input.high_precision_mode
    settings delete global input.low_latency_mode
    settings delete global input.predictive_input
    settings delete global input.auto_adjust_sensitivity
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Sensor Gyro
(
    settings delete global sensor.gyro.latency_reduction
    settings delete global sensor.gyro.low_latency_mode
    settings delete global sensor.gyro.stabilization
    settings delete global sensor.gyro.drift_correction
    settings delete global sensor.gyro.noise_reduction
    settings delete global sensor.gyro.sensitivity
    settings delete global sensor.acceleration_filtering
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Gamepad
(
    settings delete global gamepad.sensitivity
    settings delete global gamepad.deadzone_reduction
    settings delete global gamepad.input_latency_optimization
    settings delete global gamepad.aim_assist_optimization
) >/dev/null 2>&1

# Ibalik ang Default na Setting ng Rendering
(
    setprop debug.hwui.renderer ""
    setprop debug.hwui.use_vulkan ""
    setprop debug.hwui.disable_vsync ""
    setprop debug.hwui.fps_divisor ""
    setprop debug.sf.disable_backpressure ""
) >/dev/null 2>&1