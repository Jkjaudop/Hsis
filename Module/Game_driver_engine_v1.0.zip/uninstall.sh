#!/system/bin/sh

clear
echo ""
echo "🗑️-----------------------------------------------🗑️"
echo "  SHIZUKO GAME DRIVER ENGINE UNINSTALLER"
echo "     Reverting Tweaks to Default"
echo "         by Minamahal ❤️"
echo "🗑️-----------------------------------------------🗑️"
sleep 1

echo "🔄 Reverting Game Driver settings..."
settings delete global game_driver_all_apps
settings delete global game_driver_default
settings delete global game_driver_opt_out_apps
echo "✅ Game Driver settings removed."

sleep 1

echo "🔄 Reverting GPU tweaks..."
settings delete global gpu.turbo_boost
settings delete global gpu.accelerate
echo "✅ GPU tweaks removed."

sleep 1

echo "🔄 Reverting Memory settings..."
settings delete global sys.memory_boost
settings delete global activity_manager.max_cached_processes
echo "✅ Memory tweaks reverted."

sleep 1

echo "🔄 Reverting Thermal settings..."
settings delete global thermal.config
settings delete global thermal.gaming_mode
echo "✅ Thermal tweaks reverted."

sleep 1

echo "🔄 Reverting Touch & Display tweaks..."
settings delete global touch.response
settings delete global display.refresh_rate
echo "✅ Touch & display settings reverted."

sleep 1

echo ""
echo "🎉 Successfully uninstalled Shizuko Game Driver Engine!"
echo ""
echo "🗑️-----------------------------------------------🗑️"
echo "   Note:"
echo "   • Reboots may be needed for some settings to fully clear"
echo "   • Safe for Brevent user environment"
echo "🗑️-----------------------------------------------🗑️"