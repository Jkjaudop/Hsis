sleep 1
echo ""


# Deleting scheduling and CPU related settings
settings delete system sched_migration_cost_ns                  # Delete migration cost for tasks
settings delete system sched_latency_ns                          # Delete scheduler latency setting
settings delete system sched_min_granularity_ns                  # Delete minimum granularity for scheduling
settings delete system sched_wakeup_granularity_ns               # Delete wakeup granularity setting
settings delete system sched_nr_migrate                          # Delete the number of task migration attempts
settings delete system perf_cpu_time_max_percent                 # Delete the maximum CPU time percentage setting
settings delete system sched_autogroup_enabled                   # Delete the autogroup scheduling setting
settings delete system sched_child_runs_first                    # Delete child runs first scheduler setting
settings delete system sched_cstate_aware                        # Delete CPU core C-state awareness setting
settings delete system sched_energy_aware                        # Delete energy-aware scheduling setting
settings delete system sched_rr_timeslice_ms                     # Delete round-robin timeslice setting
settings delete system sched_rt_period_us                        # Delete real-time period setting
settings delete system sched_rt_runtime_us                       # Delete real-time runtime setting
settings delete system sched_sync_hint_enable                    # Delete sync hint enable setting
settings delete system sched_tunable_scaling                     # Delete tunable scaling setting

# Deleting game and caching related settings
settings put delete game_auto_temperature_control               # Delete game temperature control setting
settings put delete cached_apps_freezer                         # Delete cached apps freezer setting
setprop debug.restricted_device_performance ""                 # Reset performance tuning property

# Deleting CPU boost and input boost settings
settings delete system cpu_boost_dynamic_stune_boost            # Delete dynamic CPU boost stune setting
settings delete system cpu_boost_dynamic_stune_boost_ms         # Delete dynamic stune boost duration setting
settings delete system cpu_boost_input_boost_ms                 # Delete input boost duration setting
settings delete system cpu_boost_powerkey_input_boost_ms        # Delete power key input boost duration setting
settings delete system cpu_boost_input_boost_enabled            # Delete input boost enabled setting
settings delete system cpu_boost_sched_boost_on_powerkey_input # Delete boost on power key input setting
settings delete system cpu_boost_sched_boost_on_input           # Delete boost on any input setting

# Deleting Mali and CPU performance tuning settings
settings delete system mali_idler_parameters_mali_idler_active  # Delete Mali GPU idler active setting
settings delete system lazyplug_parameters_nr_possible_cores   # Delete lazyplug possible cores setting

# Resetting power and thermal settings
cmd power set-adaptive-power-saver-enabled true                # Enable adaptive power saver
cmd power set-fixed-performance-mode-enabled false             # Disable fixed performance mode
cmd thermalservice override-status 1                           # Enable thermal override

# Deleting graphical and surface flinger settings
settings delete global dropbox:dumpsys:procstats                # Delete process stats from Dropbox
settings delete global dropbox:dumpsys:usagestats               # Delete usage stats from Dropbox
settings put global surface_flinger.max_frame_buffer_acquired_buffers 2  # Set max acquired buffers to 2
settings delete global surface_flinger.running_without_sync_framework # Delete sync framework setting
setprop debug.cpurend.vsync true                               # Enable CPU VSYNC debugging
setprop debug.hwui.app_memory_policy normal                    # Set HWUI memory policy to normal
setprop debug.hwui.optimized_texture_upload false              # Disable texture upload optimization

# Deleting kernel, CPU boost, and thermal settings
settings delete system kernel_fpsgo_common_fpsgo_enable         # Delete FPSGO kernel setting
settings delete system cpu_boost_parameters_boost              # Delete CPU boost parameters setting
setprop debug.thermal_parameters_enable_throttle ""            # Reset thermal throttling enable setting
setprop debug.thermal_parameters_thermal_enable ""             # Reset thermal enable setting

# Deleting display and refresh rate settings
settings delete system peak_refresh_rate                       # Delete peak refresh rate setting
settings delete system minimum_refresh_rate                    # Delete minimum refresh rate setting

# Deleting performance mode and game-specific settings
settings delete system sem_enhanced_cpu_responsiveness         # Delete enhanced CPU responsiveness setting
settings delete system sem_performance_mode                    # Delete performance mode setting
settings delete system sem_turbo_mode                          # Delete turbo mode setting
settings delete system fod_animation_type                      # Delete FOD animation setting
settings delete system force_vulkan_acceleration               # Delete Vulkan acceleration setting
settings delete system fps_limit                               # Delete FPS limit setting
settings delete system game_accelerate_hw                      # Delete game hardware acceleration setting
settings delete system game_character_movement                 # Delete game character movement setting
settings delete system game_no_interruption                    # Delete game interruption setting
settings delete system gaming_processor_priority               # Delete gaming processor priority setting
settings delete system gearhead_driving_mode_settings_enabled  # Delete gearhead driving mode setting

# Deleting CPU core speeds and performance settings
settings delete global cpu.core_speeds.cluster0                # Delete CPU core speed for cluster 0
settings delete global cpu.core_speeds.cluster1                # Delete CPU core speed for cluster 1

# Deleting display, UI, and system-related settings
settings delete system display_use_color_profiles              # Delete display color profile setting
settings delete system purgeable_assets                        # Delete purgeable assets setting
settings delete system scrollingcache                          # Delete scrolling cache setting
settings delete system shutdown_mode                           # Delete shutdown mode setting
settings delete system sys_ui_hw                               # Delete system UI hardware setting
settings delete system sys_use_dithering                       # Delete dithering setting
settings delete system config_hw_fast_dormancy                 # Delete fast dormancy setting
settings delete system config_hw_quickpoweron                  # Delete quick power on setting
settings delete system config_nocheckin                        # Delete no check-in configuration
settings delete system ril_disable_power_collapse             # Delete RIL power collapse setting
settings delete system ril_hsxpa                               # Delete RIL HSXPA setting

# Deleting background app and Wi-Fi settings
settings delete system fw_bg_apps_limit                        # Delete background apps limit setting
settings delete system vendor_qti_sys_fw_b_bg_apps_limit       # Delete QTI background apps limit setting
settings delete system vendor_qti_wifi_ssr_bw                  # Delete QTI Wi-Fi SSR bandwidth setting
settings delete system wifi_supplicant_scan_interval          # Delete Wi-Fi supplicant scan interval setting

# Deleting stune and CPU set configurations
settings delete system stune_background_schedtune.boost        # Delete background schedtune boost setting
settings delete system stune_background_schedtune.colocate     # Delete background schedtune colocation setting
settings delete system stune_background_schedtune.prefer_idle # Delete background schedtune idle preference setting
settings delete system stune_background_schedtune.sched_boost # Delete background schedtune boost setting
settings delete system stune_background_schedtune.sched_boost_no_override # Delete no override for background boost setting
settings delete system stune_background_schedtune.prefer_perf # Delete background schedtune performance preference setting
settings delete system stune_background_schedtune.util_est_en # Delete background schedtune utilization estimation setting
settings delete system stune_background_schedtune.ontime_en   # Delete background schedtune on-time enable setting
settings delete system stune_background_schedtune.prefer_high_cap # Delete background schedtune high-cap preference setting

settings delete system stune_foreground_schedtune.boost        # Delete foreground schedtune boost setting
settings delete system stune_foreground_schedtune.colocate     # Delete foreground schedtune colocation setting
settings delete system stune_foreground_schedtune.prefer_idle # Delete foreground schedtune idle preference setting
settings delete system stune_foreground_schedtune.sched_boost # Delete foreground schedtune boost setting
settings delete system stune_foreground_schedtune.sched_boost_no_override # Delete no override for foreground boost setting
settings delete system stune_foreground_schedtune.prefer_perf # Delete foreground schedtune performance preference setting

# Deleting CPU core set configurations
settings delete system cpu_set_effective_cpus                  # Delete effective CPUs setting
settings delete system cpu_set_background_cpus                 # Delete background CPUs setting
settings delete system cpu_set_background_effective_cpus       # Delete effective background CPUs setting
settings delete system cpu_set_system-background_cpus          # Delete system background CPUs setting
settings delete system cpu_set_system-background_effective_cpus # Delete effective system background CPUs setting
settings delete system cpu_set_foreground_cpus                 # Delete foreground CPUs setting
settings delete system cpu_set_foreground_effective_cpus       # Delete effective foreground CPUs setting
settings delete system cpu_set_top-app_cpus                    # Delete top app CPUs setting
settings delete system cpu_set_top-app_effective_cpus          # Delete effective top app CPUs setting
settings delete system cpu_set_restricted_cpus                 # Delete restricted CPUs setting
settings delete system cpu_set_restricted_effective_cpus       # Delete effective restricted CPUs setting

(
    settings delete system user_refresh_rate
    settings delete system fps_limit
    settings delete system max_refresh_rate_for_ui
    settings delete system hwui_refresh_rate
    settings delete system display_refresh_rate
    settings delete system max_refresh_rate_for_gaming
    settings delete system peak_refresh_rate
    settings delete system thermal_limit_refresh_rate
    settings delete system max_refresh_rate
    settings delete system min_refresh_rate
    settings delete system thermal_limit_refresh_refresh_rate
) > /dev/null 2>&1 &

#!/system/bin/sh

(
settings delete global window_animation_scale
settings delete global transition_animation_scale
settings delete global animator_duration_scale
settings delete secure display_density_forced
settings delete system tap_duration
settings delete system view.scroll_friction
settings delete secure pointer_speed
input swipe 500 1000 900 1000 50
input tap 500 500
settings delete system devices_virtual_input_input1_polling_rate 
settings delete global touch_sampling_rate
settings delete global input.sampling_rate
settings delete system persist.sys.touch.sampling_boost 
settings delete global input.delay 
settings delete global input.resampling 
settings delete global input.gesture_prediction 
settings delete global input.touch_boost
settings delete global min.touch.major 
settings delete global min.touch.minor 
settings delete system touch.boost 
settings delete system touch.responsive 
settings delete system touch_sampling_rate
settings delete system touch_size_calibration
settings delete system touch_stats
settings delete system touchX_debuggable 
settings delete system touch_boost_threshold 
settings delete system touch_feature_gamemode_enable 
settings delete system touch_input_sensitivity 
settings delete system touch_rate_control 
settings delete system touch_response_rate 
settings delete system touch_sampling_rate_override 
settings delete system touch_sensitivity
settings delete system touch_slop 
settings delete system touch_switch_set_touchscreen
settings delete system touch_tap_sensitivity 
settings delete system touchpanel_game_switch_enable
settings delete global surface_flinger.start_graphics_allocator_service
settings delete global surface_flinger.running_without_sync_framework
setprop debug.sf.luma_sampling ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.sf.enable_layer_caching ""
setprop debug.sf.enable_hwc_vds ""
setprop debug.sf.hw ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.late.sf.duration ""
setprop debug.sf.late.app.duration ""
setprop debug.sf.treat_170m_as_sRGB ""
setprop debug.sf.earlyGl.app.duration ""
setprop debug.sf.frame_rate_multiple_threshold ""
setprop debug.boot.fps ""
setprop debug.performance.tuning ""
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
settings delete system haptic_feedback_intensity
settings delete global tactile_feedback_enabled
settings delete global fw.bservice_enable 
settings delete global fw.bg_apps_limit
settings delete global fw.bservice_limit
settings delete global fw.bservice_age 
setprop debug.touch.pressure.scale ""
setprop debug.touch_move_opt ""
setprop debug.touch_vsync_opt ""
cmd device_config delete input default_key_press_repeat_rate
cmd device_config delete input filtered_accel_event_rate_hz
cmd device_config delete input touch_screen_sample_interval_ms
cmd device_config delete systemui cg_frame_interval_millis
cmd device_config delete systemui low_power_refresh_rate_millis
cmd device_config delete systemui cg_max_frame_skip
setprop debug.touch.size.bias 
setprop debug.MultitouchSettleInterval 
setprop debug.TapInterval 
setprop debug.TapSlop 
setprop debug.security.mdpp 
setprop debug.security.mdpp.result 
setprop debug.service.lgospd.enable 
setprop debug.service.pcsync.enable 
setprop debug.touch.deviceType 
setprop debug.boosterorientnosync 
setprop debug.egl.swapinterval 
settings delete global windowsmgr.max_events_per_sec
settings delete global min_pointer_dur
settings delete global product.multi_touch_enabled
settings delete global securestorage.knox
settings delete global sf.disable_smooth_effect
settings delete global block_untrusted_touches
settings delete global KeyRepeatDelay
settings delete global KeyRepeatTimeout
settings delete global DragMinSwitchSpeed
settings delete global SwipeMaxWidthRatio
settings delete secure touch_distance_scale
settings delete secure view_scroll_friction
settings delete secure multi_touch_enabled
settings delete secure assist_touch_gesture_enabled
settings delete secure touch_size_scale
settings delete secure show_rotation_suggestions
settings delete secure touch_size_bias
settings delete secure touch_exploration_enabled
settings delete secure touch_orientationAware
settings delete secure touch_pressure_scale
settings delete secure dev.pm.dyn_samplingrate
settings delete system af.resampler.quality
settings delete system scrollingcache
settings delete system show_touches
settings delete system vsync.disable.fps.limit
settings delete system table.framerate
settings delete system disable.hwc.delay
settings delete system Touc_xRotation
settings delete system touchswipedeadzone
settings delete system pointer_speed
settings delete system touchscreen_hovering
settings delete system touchscreen_sensitivity_mode
settings delete system touchscreen_pressure_calibration
settings delete system touchscreen_threshold
settings delete system touchfeature.gamemode.enable
settings delete system r.setframepace
settings delete system touchpanel_oppo_tp_direction
settings delete system touchpanel_oppo_tp_limit_enable
settings delete system use_dithering
settings delete system qti.inputopts.enable
settings delete system qti.inputopts.movetouchslop
settings delete system MovementSpeedRatio
settings delete system ZoomSpeedRatio
settings delete system SwipeTransitionAngleCosine
settings delete system mot.proximity.distance
settings delete system PointerVelocityControlParameters
settings delete system device.internal
settings delete system touchscreen_min_press_time
settings delete system touchscreen_gesture_mode
settings delete system touchscreen_pointer_speed
settings delete system touchscreen_sensitivity_threshold
settings delete system touchscreen_double_tap_speed
settings delete system touchscreen_sensitivity_scale
settings delete system SurfaceOrientation
settings delete system touch.size.calibration
settings delete system touch.size.scale
settings delete system touch.size.isSummed
settings delete system touch.orientation.calibration
settings delete system touch.distance.scale
settings delete system touch.coverage.calibration
settings delete system touch.pressure.scale
settings delete system touch.gesturemode
settings delete system MultitouchMinDistance
settings delete system scroll.accelerated.hw
settings delete system ui.hwframes
settings delete system force_high_end_gfx
settings delete system max_num_touch
settings delete system view.touch_slop
settings delete system maxeventspersec
settings delete system resampler.quality
settings delete system adaptive_touch_sensitivity
settings delete system PressureForID
settings delete system QuietInterval
settings delete system AIM_SENSITIVITY_TRANSITION_TIME
settings delete system APP_SWITCH_DELAY_TIME
settings delete system AbsoluteXForID
settings delete system AccelerationX
settings delete system AccelerationY
settings delete system DoubleTouch
settings delete system PowerbuttonTapping
settings delete system touch.assistant.enabled
settings delete system type.touch_speed
settings delete system accuracy.control
) > /dev/null 2>&1