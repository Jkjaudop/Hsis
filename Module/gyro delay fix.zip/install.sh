#!/system/bin/sh

echo ""
echo "=========================================="
echo "🔧 Gyroscope Delay Fix - Brevent 🌀"
echo "✨ by Minamahal & minamahal ko @jaloyd_tqeaks x minamahal ❤️"
echo "=========================================="

sleep 1

# Show current device info
echo ""
echo "📱 Device Information:"
echo "-------------------------------"
echo "Brand: $(getprop ro.product.brand)"
sleep 1.0
echo "Model: $(getprop ro.product.model)"
sleep 0.5
echo "Device: $(getprop ro.product.device)"
sleep 0.5
echo "Manufacturer: $(getprop ro.product.manufacturer)"
sleep 0.5
echo "Android Version: $(getprop ro.build.version.release)"
sleep 0.5
echo "Build: $(getprop ro.build.display.id)"
sleep 0.5
echo "Board: $(getprop ro.product.board)"
sleep 0.5
echo "Hardware: $(getprop ro.hardware)"
echo "-------------------------------"
echo "- Done"
am start -a android.intent.action.VIEW -d https://t.me/+oM_l4lwFroI3ZWI1 >/dev/null 2>&1
cmd notification post -S bigtext -t 'GYRO DELAY FIX' 'Tag' 'GYRO HAS BEEN FIXED' > /dev/null 2>&1
sleep 1

# Gyro latency and batching
settings put global sensor.non_wakeup_batching_delay 0
settings put global sensor.wakeup_batching_delay 0
settings put global gyro.sensor.wakeup 1
settings put global gyro.sensor.delay 0
settings put global gyro.sensor.latency 0
settings put global gyro.batch_latency 0
settings put global gyro.delay 0
settings put global gyro.delay_ns 0
settings put global gyro.sensor.fastest_rate 1
settings put global gyro.sensor.batch_timeout 0
settings put global gyro.sensor.min_delay 0
settings put global gyro.sensor.max_delay 0
settings put global gyro.sensor.batch_latency_ns 0
settings put global gyro.sensor.polling_rate_hz 1000
settings put global gyro.sensor.report_latency_ns 0

# Accelerometer
settings put global accel.sensor.delay 0
settings put global accel.sensor.latency 0
settings put global accel.sensor.polling_rate_hz 1000
settings put global accel.sensor.report_latency_ns 0

# Sensor batching tweaks
settings put global persist.sensor.batch_wakeup 1
settings put global persist.sensor.low_latency_mode 1
settings put global persist.sensor.fastest_rate 1
settings put global persist.sensor.gyro.low_latency true
settings put global persist.gyro.low_latency true

echo ""
echo "✅ Gyroscope optimization applied successfully!"
sleep 2.0
echo "📌 Execute complete - Restart your game for effect."
sleep 1.0
echo "=========================================="
    