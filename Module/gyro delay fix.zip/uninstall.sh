echo "🧹 Reverting Gyro delay fix..."
settings delete global gyro.delay
echo "✅ Gyro delay reset to system default"