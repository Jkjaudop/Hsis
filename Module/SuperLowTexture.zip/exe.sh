device_config put game_overlay com.garena.game.codm mode=2,downscaleFactor=0.2,fps=60
cmd game set  --downscale 0.1 --fps 60 com.garena.game.codm