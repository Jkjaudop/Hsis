device_config delete game_overlay com.garena.game.codm
cmd game set --mode 0 com.garena.game.codm
cmd game mode 0 com.garena.game.codm