#vexiro(maindata)
echo ""
echo "Instalasi Module Please Wait"
sleep 2
(
#Set Zram
settings put global zram_enabled 1
settings put global ram_expand_size 10240
#Maximal Zram Config 
settings put global activity_manager_constants max_cached_processes 8
settings put global app_standby_enabled true
settings put global cached_app_lru_limit 16
) > /dev/null 2>&1
echo "Done"