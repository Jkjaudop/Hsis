(
#Reset Zram
settings put  global zram_enabled  0
settings delete global ram_expand_size 
#Maximal Zram Config Delete
settings delete global activity_manager_constants max_cached_processes 
settings delete global app_standby_enabled
settings delete global cached_app_lru_limit 
) > /dev/null 2>&1