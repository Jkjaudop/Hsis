sleep 1
echo ""


# --- Start of Pipeline Rendering Configuration ---

# Set OpenGL renderer for hardware UI rendering
(setprop debug.hwui.renderer opengl; \
for a in $(pm list packages | grep -v ia.mo | cut -f2 -d:); do "$a" & done) >/dev/null 2>&1 &

# --- Rendering Tweaks ---
(
    # Shader and rendering optimizations
    setprop debug.rs.shader 0
    setprop debug.rs.shader.attributes 0
    setprop debug.rs.shader.uniforms 0
    setprop debug.rs.profile 0
    setprop debug.rs.script 0
    setprop debug.rs.visual 0
    setprop debug.rs.debug 0
    setprop debug.rs.precision rs_fp_relaxed
    setprop debug.rs.forcecompat 0
    setprop debug.rs.default-CPU-driver 0
    setprop debug.rs.default-GPU-driver 1
    setprop debug.rs.default-CPU-buffer 262144
    
    # Shader cache and layer optimization settings
    setprop debug.sf.prime_shader_cache.solid_dimmed_layers false
    setprop debug.sf.prime_shader_cache.image_dimmed_layers false
    setprop debug.sf.prime_shader_cache.image_layers false
    setprop debug.sf.prime_shader_cache.clipped_layers false
    setprop debug.sf.prime_shader_cache.shadow_layers false
    setprop debug.sf.prime_shader_cache.pip_image_layers false
    setprop debug.sf.prime_shader_cache.transparent_image_dimmed_layers false
    setprop debug.sf.prime_shader_cache.clipped_dimmed_image_layers false
    setprop debug.sf.enable_layer_caching 0
    setprop debug.sf.layer_caching_active_layer_timeout_ms 0
    setprop debug.sf.prime_shader_cache.all_layers false
    setprop debug.sf.prime_shader_cache.hole_punch false
    setprop debug.sf.prime_shader_cache.solid_layers false
) >/dev/null 2>&1 &

# --- UI Performance Optimizations for Gaming ---
(
    # Disable render thread and enable threaded rendering for UI
    settings put global debug.hwui.disable_render_thread 1
    setprop debug.hwui.use_threaded_renderer true
    setprop debug.hwui.disable_vsync true
    setprop debug.hwui.vsync_override 1
    setprop debug.hwui.min_frames_rendered 3
    setprop debug.hwui.jank_avoidance true

    # Set frame rate and composition settings for optimal UI performance
    setprop debug.sf.frame_rate_multiple_threshold 2
    setprop debug.sf.latch_unsignaled 1
    setprop debug.sf.enable_frame_rate_override true
    setprop debug.sf.predict_hwc_composition_strategy 0
    setprop debug.hwui.disable_partial_updates false
    setprop debug.sf.disable_client_composition_cache 1
    
    # Buffer management
    settings put global buffer_queue_max_buffer_count 2
    settings put global surface_flinger.use_color_management true
) >/dev/null 2>&1 &

# --- Reducing Shadow Rendering Load (Monolithic) ---
(
    # Set shadow rendering mode to monolithic for reduced complexity
    setprop debug.hwui.shadow.renderer monolithic
    setprop debug.hwui.drop_shadow_cache_size 0
    setprop debug.hwui.texture_cache_size 50
    setprop debug.hwui.gradient_cache_size 1
    setprop debug.hwui.path_cache_size 10
    setprop debug.hwui.shape_cache_size 5
    setprop debug.hwui.layer_cache_size 15
    setprop debug.hwui.disable_scissor_opt true
) >/dev/null 2>&1 &

# --- Optimizing Rendering Pipeline ---
(
    # Enabling hint manager and optimizing CPU/GPU time allocation
    setprop debug.hwui.use_hint_manager true
    setprop debug.hwui.target_cpu_time_percent 200
    setprop debug.hwui.target_gpu_time_percent 200
    setprop debug.hwui.enable_f16 true
    setprop debug.hwui.enable_partial_updates false
) >/dev/null 2>&1 &

# --- Stabilizing UI Rendering FPS and OpenGL Lite Configuration ---
(
    # Set frame rate divisors and disable backpressure for smoother UI rendering
    setprop debug.hwui.fps_divisor 1
    setprop debug.sf.disable_backpressure 1

    # Force OpenGL Lite rendering pipeline
    setprop debug.sf.pipeline opengl

    # Additional stability optimizations for rendering
    setprop debug.sf.auto_latch_unsignaled 0
    setprop debug.sf.early.app.duration 25000000
    setprop debug.sf.early.sf.duration 22500000
    setprop debug.sf.earlyGl.app.duration 25000000
    setprop debug.sf.earlyGl.sf.duration 22500000
    setprop debug.sf.enable_advanced_sf_phase_offset 1
    setprop debug.sf.enable_gl_backpressure false
    setprop debug.sf.enable_hwc_vds 0
    setprop debug.sf.hw 0
    setprop debug.sf.late.app.duration 25000000
    setprop debug.sf.late.sf.duration 22500000
    setprop debug.sf.predict_hwc_composition_strategy 0
    setprop debug.sf.treat_170m_as_sRGB 1
    setprop debug.sf.use_phase_offsets_as_durations 1

    # Enforce OpenGL version 2.0 for GPU rendering
    setprop debug.egl.version 0x20000
    setprop debug.gpu.renderer opengl
    setprop debug.hwui.renderer opengl
    setprop debug.renderengine.backend opengl
    setprop debug.composition.type skiagl

    # Additional settings for OpenGL rendering stability
    settings put global debug.hwui.use_vulkan false
    settings put global gpu_debug_layers_on 1

    # OpenGL Lite and rendering optimizations
    settings put global enable_gpu_renderer true
    settings put global use_egl_mode 1
    settings put global debug_hwui_renderer opengl
    settings put global gpu_debug_layers_on 1
    settings put global enable_opengl_lite 1
    settings put global debug_enable_scissor_optimization true
    settings put global buffer_size 0.5
    settings put global hwui_disable_vsync 1

    # Additional debugging options for OpenGL performance
    setprop debug.rs.visual opengl
    setprop debug.rs.shader SPIR-V
    setprop debug.hw.vsync 0
    setprop debug.generate-debug-info false
    setprop debug.egl.traceGpuCompletion false
    setprop debug.sf.use_frame_rate_priority 1

    # Further optimization and cache settings
    settings put global hwui.renderer opengl
    settings put system surface_flinger_use_frame_rate_api null
    setprop debug.hwui.disable_zrle 1
    setprop debug.hwui.vsync_override 1
    settings put global hwui.texture_cache_flushrate 0.4
    settings put global texture_atlas_cache_override 0.25
    settings put global texture_atlas_cache_entry_override 0.034
    settings put global texture_atlas_map_pool_override 0.15
) > /dev/null 2>&1

# --- End of Configuration ---