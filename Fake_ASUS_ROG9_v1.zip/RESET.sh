cmd notification post -S bigtext -t 'FAKE ASUS ROG 9' 'Tag' 'PROSES UNINSTALL' > /dev/null 2>&1
echo ""
echo "█▓▒▒░░FAKE ASUS ROG 9░░░▒▒▓█"
echo ""
sleep 0.5
echo "│ 📱 Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU      : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU      : $(getprop ro.hardware) │"
echo "│ 📲 Android  : $(getprop ro.build.version.release) │"
echo "│ 🔥 Thermal  : $(cat /sys/class/thermal/thermal_zone0/temp)°C │"
echo "│ 🔰 Kernel   : $(uname -r) │"
echo "│ 🔹 Build    : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) │"
echo "│ 🔗 SELinux  : $(getenforce) │"
echo "└───────────────────────────────────────┘"
echo ""
echo "█▓▒▒░░░WELCOME TO UNINSTALL░░░▒▒▓█"
echo ""
sleep 0.5
echo ""
echo "
██████╗░███████╗██╗░░░░░███████╗████████╗███████╗
██╔══██╗██╔════╝██║░░░░░██╔════╝╚══██╔══╝██╔════╝
██║░░██║█████╗░░██║░░░░░█████╗░░░░░██║░░░█████╗░░
██║░░██║██╔══╝░░██║░░░░░██╔══╝░░░░░██║░░░██╔══╝░░
██████╔╝███████╗███████╗███████╗░░░██║░░░███████╗
╚═════╝░╚══════╝╚══════╝╚══════╝░░░╚═╝░░░╚══════╝"
echo ""
sleep 0.5
echo ""
echo "PROSES UNINSTALL MODULE"
echo ""
sleep 3
(
#Peformance Stability 
setprop debug.egl.force_msaa ""
setprop debug.hwui.use_gpu_pixel_buffers ""
setprop debug.hwui.target_cpu_time_percent ""
setprop debug.hwui.render_dirty_regions ""
setprop debug.hwui.disable_vsync ""
setprop debug.hwui.level ""
setprop debug.kill_allocating_task ""
setprop debug.gralloc.gfx_ubwc_disable ""
setprop debug.rs.default-CPU-driver ""
setprop debug.rs.forcecompat ""
setprop debug.rs.max-threads ""
setprop debug.choreographer.skipwarning ""
setprop debug.choreographer.frametime ""
setprop debug.display.allow_non_native_refresh_rate_override ""
setprop debug.display.render_frame_rate_is_physical_refresh_rate ""
setprop debug.sf.use_phase_offsets_as_durations ""
setprop debug.sf.predict_hwc_composition_strategy ""
setprop debug.sf.enable_transaction_tracing ""
setprop debug.sf.disable_client_composition_cache ""
setprop debug.sf.gpu_freq_indeks ""
setprop debug.sf.use_frame_rate_priority ""
setprop debug.sf.disable_backpressure ""
setprop debug.sf.enable_gl_backpressure ""
setprop debug.atrace.tags.enableflags ""
setprop debug.cpurend.vsync ""
setprop debug.composition.type ""
setprop debug.checkjni ""
setprop debug.atrace.tags.enableflags ""
setprop debug.gr.numframebuffers ""
# CPU Spoof (Qualcomm Snapdragon 8 Elite)
settings delete global ro.vendor.soc.model.external_name 
settings delete global ro.vendor.soc.model.part_name 
settings delete global ro.soc.manufacturer
settings delete global ro.soc.model
# Spoofing ROG PHONE 9 ELITE
settings delete global ro.product.brand
settings delete global ro.product.manufacturer
settings delete global ro.product.model
settings delete global ro.product.marketname
settings delete global ro.product.system.marketname
settings delete global ro.product.system.model 
settings delete global ro.product.vendor.model 
settings delete global ro.product.vendor.marketname 
settings delete global ro.product.vendor.manufacturer 
settings delete global ro.product.vendor.brand 
settings delete global ro.product.odm.marketname 
settings delete global ro.product.odm.model 
settings delete global ro.product.product.marketname 
settings delete global ro.product.product.model 
settings delete global ro.build.product 
settings delete global ro.chipset
# Spoff Chipset
settings delete global ro.soc.manufacturer 
settings delete global ro.vendor.soc.manufacturer
settings delete global ro.hardware.chipname 
settings delete global ro.chipname
settings delete global ro.soc.model 
settings delete global ro.vendor.soc.model 
settings delete global ro.soc.model.external_name 
settings delete global ro.soc.model.part_name 
settings delete global ro.qti.soc_name 
settings delete global ro.qti.soc_model 
settings delete global ro.mtk.soc_name 
settings delete global ro.mtk.soc_model
settings delete global ro.vendor.soc.model.external_name 
settings delete global ro.vendor.soc.model.part_name
settings delete global ro.vendor.qti.soc_name 
settings delete global ro.vendor.qti.soc_model 
settings delete global ro.vendor.mtk.soc_name 
settings delete global ro.vendor.mtk.soc_model 
#SPOFF FAKE DEVICE NON ROOT
settings delete global device_name
settings delete system model 
settings delete global ro.product.model 
settings delete global ro.product.manufacturer
settings delete global ro.vendor.product.cpu.abilist 
settings delete global ro.product.brand
settings delete global ro.product.device 
settings delete global ro.product.manufacturer
settings delete global ro.product.model 
settings delete global product.marketname 
settings delete global ro.soc.vendor Qualcomm
settings delete global ro.product.system_ext.brand 
settings delete global ro.product.system_ext.device 
settings delete global ro.product.system_ext.manufacturer
settings delete global ro.product.system_ext.marketname 
settings delete global ro.product.vendor.cert 
settings delete global ro.product.Aliases
settings delete global ro.build.tf.modelnumber
settings delete global ro.soc.model
settings delete global ro.soc.vendor
settings delete global ro.soc.manufacturer 
settings delete global ro.soc.model
settings delete global ro.product.cpu.abi
settings delete global ro.product.cpu.abilist
settings delete global ro.product.cpu.name 
settings delete global ro.hardware.chipname 
settings delete global ro.vendor.qti.chip_name
) > /dev/null 2>&1
# Confirming reversion
echo ""
echo "Settings reverted to default."
echo ""
sleep 0.5
echo""
echo "ALL DONE DELETE[✓]"
echo""
sleep 0.5
echo""
echo "AljoPH"
echo""
sleep 0.5
echo""
echo "THANKS"
echo""
sleep 0.5
echo""
echo "Successfully Deleted Fake Device Database"
echo""
sleep 0.5
echo""
echo "█▓▒▒░░░THANKS FOR USING MODULE ░░░▒▒▓█"
echo""
cmd notification post -S bigtext -t 'FAKE ASUS ROG 9' 'Tag' 'Successfully Deleted All Configurations & Tweaks.,' > /dev/null 2>&1
