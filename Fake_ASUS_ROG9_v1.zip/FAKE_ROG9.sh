cmd notification post -S bigtext -t 'ASUS ROG 9' 'Tag' 'PROSES INSTALING' > /dev/null 2>&1
echo ""
echo "█▓▒▒░░░FAKE DEVICE ASUS ROG 9░░░▒▒▓█"
echo ""
sleep 0.5
echo "│ 📱 Device   : $(getprop ro.product.manufacturer) $(getprop ro.product.model) │"
echo "│ ⚙️ CPU      : $(getprop ro.board.platform) │"
echo "│ 🎮 GPU      : $(getprop ro.hardware) │"
echo "│ 📲 Android  : $(getprop ro.build.version.release) │"
echo "│ 🔥 Thermal  : $(cat /sys/class/thermal/thermal_zone0/temp)°C │"
echo "│ 🔰 Kernel   : $(uname -r) │"
echo "│ 🔹 Build    : $(getprop ro.build.display.id) │"
echo "│ 🛑 Root     : $(if [ $(id -u) -eq 0 ]; then echo 'Yes'; else echo 'No'; fi) │"
echo "│ 🔗 SELinux  : $(getenforce) │"
echo "└───────────────────────────────────────┘"
echo ""
echo "█▓▒▒░░░WELCOME TO INSTALASI░░░▒▒▓█"
echo ""
sleep 0.5
echo "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠠⢀⡄⢄⡠⣖⠲⢶⡤⠤⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠀⠀⠒⠐⠀⢀⡡⢠⡐⡄⡢⠖⠀⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡀⠘⠀⠀⣠⣴⡶⣯⡷⠏⠃⠁⠀⠀⠀⠀⡀⠀⠰⠂⠠
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⢊⠀⣠⣶⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠉⢀⣀⡤⠖⠁
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⠪⣔⣵⣿⣿⡿⠛⠁⠀⠀⠀⡀⠤⡐⡈⣔⣤⣶⢾⡻⢝⡖⠀⠀
⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⢞⣦⣿⣿⡿⠟⠉⠀⠀⢀⡠⣄⡳⣌⣧⣷⣿⡛⢉⠂⣥⣴⣟⠁⠀⠀
⠀⣶⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣾⣽⣾⡿⠟⠉⠀⠀⣀⣴⡺⣧⢿⣼⡿⣛⣩⢖⡱⣎⢧⣟⣷⣻⠀⠀⠀⠀
⠀⠸⣞⣆⠀⠀⢀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣤⣾⣿⣿⠿⠋⠀⢀⣠⣴⣟⣿⣾⠿⠟⣋⣵⣺⣵⡯⠾⣿⣿⣿⣻⢾⠁⠀⠀⠀⠀
⠀⠀⢻⣿⣷⡄⠀⠑⣦⣦⣄⡀⠀⠀⠀⢀⣴⣿⣿⡿⠟⠉⢀⣤⣶⣟⣿⠾⠟⢋⣤⣶⡿⠿⠚⠉⠁⠀⣼⣿⣿⢷⣯⠃⠀⠀⠀⠀⠀
⠀⠀⠀⠙⢿⣿⣦⡀⠘⣿⣿⣿⣶⣦⣴⣿⣿⠟⠋⢀⣤⡾⣯⣷⠿⠋⣁⣴⠾⠛⠉⠁⠀⠀⠀⠀⠀⣼⣿⣿⢯⣟⠂⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠈⠙⠷⣄⠘⢿⣿⣿⣿⣿⠟⢁⣠⣾⣿⣿⠿⠋⠁⠔⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⢠⣾⣿⡿⣯⣟⠂⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢻⣿⡿⡏⠶⣿⢿⣻⣭⣅⡤⢠⡀⢀⡀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣿⣿⢯⣟⡷⠁⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣷⣷⣀⠀⠉⠉⠛⠺⠿⢿⡽⣟⣯⣽⣾⣾⢿⣿⣿⣿⢿⣿⣻⣞⡿⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⢿⣦⠀⠀⠀⠀⠀⠀⠀⠈⠉⠁⠛⠚⠛⠓⠻⠾⠿⠷⠛⠉⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠑⠄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⢠⠤⢤⡄⣤⠤⠤⢠⠤⢤⡀⡄⠀⢠⢠⡤⠤⣄⢠⡄⠀⢠⢀⡤⠤⣤⠀⢀⡤⠤⣤⢠⡤⠤⠄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠸⠒⠺⠇⠿⠭⠥⠸⠒⠚⠁⠧⠤⠼⠸⠯⠭⠷⠸⠧⠤⠸⠘⠧⠤⠶⠀⠸⠧⠤⠼⠸⠏⠙⠁⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠩⢽⡆⣰⣛⣆⢸⡿⣆⡼⣿⢸⡯⠭⠡⣯⣍⣿⠸⠯⠭⡅⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠉⠉⠉⠁⠈⠉⠈⠁⠈⠀⠉⠈⠉⠉⠁⠁⠀⠉⠈⠉⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀"
echo ""
sleep 0.5
echo ""
echo "⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀⣀
⣿⣿⢻⢻⡛⡟⡏⡿⡿⡿⣿⢻⣿
⣿⡿⣿⢿⡷⣟⣿⢿⡿⣿⢿⣿⣿
⣿⣿⣯⣿⡽⣿⡽⡟⠝⠁⣿⣟⣿
⣿⣿⣿⣯⣷⢯⣷⡃⠀⠀⠙⠿⣽
⣿⣮⣽⣿⣿⡿⣟⢷⣤⡀⠀⠀⠀
⣿⣽⣿⡿⣿⣿⣿⡀⠀⠹⡄⠀⠀
⠛⠛⠛⠛⠛⠛⠛⠛⠂⠤⠁⠄⠂ "
echo ""
sleep 3
(
#Peformance Stability 
setprop debug.egl.force_msaa false
setprop debug.hwui.use_gpu_pixel_buffers 1
setprop debug.hwui.target_cpu_time_percent 10
setprop debug.hwui.render_dirty_regions false
setprop debug.hwui.disable_vsync true
setprop debug.hwui.level 0
setprop debug.kill_allocating_task 0
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.rs.default-CPU-driver 1
setprop debug.rs.forcecompat 1
setprop debug.rs.max-threads 8
setprop debug.choreographer.skipwarning 30
setprop debug.choreographer.frametime false
setprop debug.display.allow_non_native_refresh_rate_override 1
setprop debug.display.render_frame_rate_is_physical_refresh_rate 1
setprop debug.sf.use_phase_offsets_as_durations 1
setprop debug.sf.predict_hwc_composition_strategy 0
setprop debug.sf.enable_transaction_tracing false
setprop debug.sf.disable_client_composition_cache 1
setprop debug.sf.gpu_freq_indeks 7
setprop debug.sf.use_frame_rate_priority 1
setprop debug.sf.disable_backpressure 1
setprop debug.sf.enable_gl_backpressure 1
setprop debug.atrace.tags.enableflags 0
setprop debug.cpurend.vsync false
setprop debug.composition.type gpu
setprop debug.checkjni 0
setprop debug.atrace.tags.enableflags 0
setprop debug.gr.numframebuffers 3
# CPU Spoof (Qualcomm Snapdragon 8 Elite)
settings put global ro.vendor.soc.model.external_name Qualcomm® "Snapdragon™ 8 Elite"
settings put global ro.vendor.soc.model.part_name SM8750-AB
settings put global ro.soc.manufacturer Qualcomm
settings put global ro.soc.model "Snapdragon™ 8 Elite"
# Spoofing ROG PHONE 9 ELITE
settings put global ro.product.brand asus
settings put global ro.product.manufacturer asus
settings put global ro.product.model ASUSAI2501
settings put global ro.product.marketname "ASUS ROG 9"
settings put global ro.product.system.marketname "ASUS ROG 9"
settings put global ro.product.system.model ASUSAI2501
settings put global ro.product.vendor.model ASUSAI2501
settings put global ro.product.vendor.marketname "ASUS ROG 9"
settings put global ro.product.vendor.manufacturer asus
settings put global ro.product.vendor.brand asus
settings put global ro.product.odm.marketname "ASUS ROG 9"
settings put global ro.product.odm.model ASUSAI2501
settings put global ro.product.product.marketname "ASUS ROG 9"
settings put global ro.product.product.model ASUSAI2501
settings put global ro.build.product ASUSAI2501
settings put global ro.chipset SM8750-AB
# Spoff Chipset
settings put global ro.soc.manufacturer Qualqomm
settings put global ro.vendor.soc.manufacturer QTI
settings put global ro.hardware.chipname SM8750-AB
settings put global ro.chipname SM8750-AB
settings put global ro.soc.model SM8750
settings put global ro.vendor.soc.model SM8750
settings put global ro.soc.model.external_name SM8750-AB
settings put global ro.soc.model.part_name SM8750-AB
settings put global ro.qti.soc_name SM8750-AB
settings put global ro.qti.soc_model SM8750
settings put global ro.mtk.soc_name SM8750-AB
settings put global ro.mtk.soc_model SM8750
settings put global ro.vendor.soc.model.external_name SM8750-AB
settings put global ro.vendor.soc.model.part_name SM8750-AB
settings put global ro.vendor.qti.soc_name SM8750-AB
settings put global ro.vendor.qti.soc_model SM8750
settings put global ro.vendor.mtk.soc_name SM8750-AB
settings put global ro.vendor.mtk.soc_model SM8750
#SPOFF FAKE DEVICE NON ROOT
settings put global device_name "ROG Phone 9"
settings put system model "ROG Phone 9"
settings put global ro.product.model "ROG Phone 9"
settings put global ro.product.manufacturer ASUS
settings put global ro.vendor.product.cpu.abilist arm64-v8a
settings put global ro.product.brand ASUS
settings put global ro.product.device ASUSAI2501
settings put global ro.product.manufacturer asus
settings put global ro.product.model ASUSAI2501
settings put global product.marketname "ASUS ROG 9"
settings put global ro.soc.vendor Qualcomm
settings put global ro.product.system_ext.brand ASUS
settings put global ro.product.system_ext.device ASUSAI2501
settings put global ro.product.system_ext.manufacturer ASUS
settings put global ro.product.system_ext.marketname "ASUS ROG 9"
settings put global ro.product.vendor.cert "ASUS ROG 9"
settings put global ro.product.Aliases ASUSAI2501
settings put global ro.build.tf.modelnumber ASUSAI2501
settings put global ro.soc.model SM8750
settings put global ro.soc.vendor Qualcomm
settings put global ro.soc.manufacturer "Qualcomm Technologies, Inc."
settings put global ro.soc.model "Snapdragon 8 Elite"
settings put global ro.product.cpu.abi "arm64-v8a"
settings put global ro.product.cpu.abilist "arm64-v8a,armeabi-v7a,armeabi"
settings put global ro.product.cpu.name "Snapdragon™ 8 Elite"
settings put global ro.hardware.chipname "Snapdragon™ 8 Elite"
settings put global ro.vendor.qti.chip_name SM8750
) > /dev/null 2>&1
sleep 0.5
echo""
echo "ALL SET PROSES[✓]"
sleep 0.5
echo""
echo "SUCCESS IMPLANTATION ASUS ROG 9"
sleep 3.0
echo""
echo "AljoPH"
echo""
sleep 0.5
echo""
echo "THANKS"
echo""
sleep 0.5
echo""
echo "ENJOY YOUR GAMING"
echo""
sleep 0.5
echo""
echo "█▓▒▒░░░THANKS FOR USING MODULE ░░░▒▒▓█"
echo""
cmd notification post -S bigtext -t 'ASUS ROG 9' 'Tag' ' SUCCES RUNING,.' > /dev/null 2>&1